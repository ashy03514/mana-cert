/* Drawn ribbons loosen into curved, staggered streams before a material appears.
 * This layer owns only an immutable drawing snapshot, never input or reveal state. */
(function(root){
  'use strict';
  const TAU=Math.PI*2;
  const clamp=(v,a=0,b=1)=>Math.min(b,Math.max(a,v));
  const smooth=v=>{v=clamp(v);return v*v*(3-2*v);};
  const finite=(v,fallback=0)=>Number.isFinite(v)?v:fallback;
  const rand=(i,s=0)=>{const n=Math.sin(i*127.1+s*311.7)*43758.5453;return n-Math.floor(n);};
  const rgb=hex=>/^#[0-9a-f]{6}$/i.test(hex||'')?[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)):[125,234,255];
  const tint=(a,b,t)=>a.map((n,i)=>Math.round(n+(b[i]-n)*clamp(t)));
  const rgba=(c,a)=>'rgba('+c.join(',')+','+clamp(a)+')';
  const palettes={fire:[244,170,83],water:[118,218,237],wind:[192,216,183],
    earth:[195,169,116],light:[246,231,192],dark:[171,118,225]};
  class RevealGather {
    constructor(){
      this.width=0;this.height=0;this.routes=[];this.pointCount=0;this.moteCount=0;
      this.maxPoints=1600;this.maxMotes=180;this.snapshotTime=0;this.opacity=1;
      this.renderer=null;this.options={};
    }
    resize(width,height){
      if(Number.isFinite(width)&&Number.isFinite(height)&&width>0&&height>0){
        this.width=width;this.height=height;
      }
    }
    capture(trails,width,height){
      this.routes=[];this.pointCount=0;this.moteCount=0;
      this.resize(width||trails?.width,height||trails?.height);
      if(!trails||!this.width||!this.height||trails.settings?.trailEnabled===false)return;
      this.snapshotTime=finite(trails.time);
      this.options={...trails.renderer?.options};
      this.opacity=clamp(finite(trails.settings?.trailOpacity,100)/100);
      this.renderer=root.RibbonRenderer?new root.RibbonRenderer(this.options):null;
      // Asking the live renderer for a route would mutate its geometry cache.
      // Work on a copy, including for strokes whose route has not been built yet.
      const visible=(trails.strokes||[]).filter(s=>s.points?.length&&
        (typeof trails.opacity==='function'?trails.opacity(s):1)>.03).slice(-16);
      const candidates=visible.map((s,index)=>{
        const points=s.points.filter(p=>Number.isFinite(p.x)&&Number.isFinite(p.y)).map(p=>({
          x:p.x,y:p.y,speed:finite(p.speed,.5)
        }));
        if(!points.length)return null;
        const copy={points,seed:finite(s.seed,index),released:null,sampleBudget:1600};
        let route=this.renderer?.route(copy);
        if(!route){
          let length=0;
          route={points:points.map((p,i)=>{
            if(i)length+=Math.hypot(p.x-points[i-1].x,p.y-points[i-1].y);
            return {...p,d:length,nx:0,ny:1};
          }),length};route.length=length;
        }
        return {route,seed:copy.seed,color:rgb(s.color),
          opacity:clamp(typeof trails.opacity==='function'?finite(trails.opacity(s),1):1),
          weight:Math.max(8,route.length)};
      }).filter(Boolean);
      const sum=candidates.reduce((n,s)=>n+s.weight,0);
      let remaining=this.maxPoints;
      candidates.forEach((s,index)=>{
        const budget=Math.min(remaining-(candidates.length-index-1)*2,
          Math.max(2,Math.floor(this.maxPoints*s.weight/(sum||1))));
        const count=s.route.length<1?1:Math.min(budget,Math.max(2,Math.ceil(s.route.length/3.5)+1));
        const sample=(d)=>{
          if(this.renderer)return this.renderer.at(s.route,d);
          const source=s.route.points;
          let i=1;while(i<source.length-1&&source[i].d<d)i++;
          if(source.length===1)return source[0];
          const a=source[i-1],b=source[i],f=clamp((d-a.d)/Math.max(.001,b.d-a.d));
          return {x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f,nx:0,ny:1};
        };
        const points=Array.from({length:count},(_,i)=>{
          const p=sample(s.route.length*i/Math.max(1,count-1));
          return Object.freeze({x:p.x/this.width,y:p.y/this.height,speed:.5});
        });
        const route=Object.freeze({points:Object.freeze(points),seed:s.seed,color:Object.freeze(s.color),
          opacity:s.opacity,motes:Math.min(30,Math.max(2,Math.ceil(s.route.length/20)))});
        this.routes.push(route);this.pointCount+=count;remaining-=count;
      });
      this.moteCount=Math.min(this.maxMotes,this.routes.reduce((n,s)=>n+s.motes,0));
      Object.freeze(this.routes);
    }
    line(ctx,points,width,color,opacity){
      if(points.length<2||opacity<.001)return;
      ctx.lineWidth=Math.max(.2,width);ctx.strokeStyle=rgba(color,opacity);
      ctx.beginPath();ctx.moveTo(points[0].x,points[0].y);
      for(let i=1;i<points.length;i++)ctx.lineTo(points[i].x,points[i].y);
      ctx.stroke();
    }
    glow(ctx,x,y,radius,color,opacity){
      if(opacity<.001)return;
      const g=ctx.createRadialGradient(x,y,0,x,y,radius);
      g.addColorStop(0,rgba(color,opacity));g.addColorStop(.3,rgba(color,opacity*.42));g.addColorStop(1,rgba(color,0));
      ctx.fillStyle=g;ctx.fillRect(x-radius,y-radius,radius*2,radius*2);
    }
    position(p,target,flight,seed,normal,time){
      const dx=target.x-p.x,dy=target.y-p.y,distance=Math.hypot(dx,dy);
      const nx=distance>1?-dy/distance:normal.x,ny=distance>1?dx/distance:normal.y;
      const side=rand(seed,7)>.5?1:-1;
      const bow=side*Math.min(160,36+distance*.42);
      const c1={x:p.x+dx*.16+normal.x*bow*.42,y:p.y+dy*.16+normal.y*bow*.42};
      const c2={x:target.x-dx*.18+nx*bow,y:target.y-dy*.18+ny*bow};
      const u=1-flight,wave=Math.sin(flight*Math.PI)*Math.sin(time*2.2+seed+flight*7)*2.5;
      return {x:u*u*u*p.x+3*u*u*flight*c1.x+3*u*flight*flight*c2.x+flight**3*target.x+nx*wave,
        y:u*u*u*p.y+3*u*u*flight*c1.y+3*u*flight*flight*c2.y+flight**3*target.y+ny*wave};
    }
    draw(ctx,{progress=0,formation=0,width=this.width,height=this.height,target,element='fire',time=0}={}){
      if(!ctx||!this.routes.length)return;
      this.resize(width,height);width=this.width;height=this.height;
      progress=clamp(finite(progress));formation=clamp(finite(formation));time=finite(time);
      if(!width||!height||formation>=.4)return;
      target={x:finite(target?.x,width/2),y:finite(target?.y,height*.5)};
      const colorTarget=palettes[element]||palettes.fire,colorMix=smooth((progress-.56)/.38);
      const scale=clamp(Math.min(width,height)/390,.65,1.6),widthScale=clamp(finite(this.options.width,1),.3,3);
      const glowScale=clamp(finite(this.options.glowSize,1),.25,2);
      const glowOpacity=clamp(finite(this.options.glowOpacity,1),0,2);
      ctx.save();ctx.globalCompositeOperation='source-over';ctx.lineCap='round';ctx.lineJoin='round';
      ctx.globalAlpha=this.opacity;
      let moteBudget=this.maxMotes;
      for(const route of this.routes){
        const points=route.points.map(p=>({x:p.x*width,y:p.y*height,speed:p.speed}));
        let length=0;
        for(let i=0;i<points.length;i++){
          if(i)length+=Math.hypot(points[i].x-points[i-1].x,points[i].y-points[i-1].y);
          points[i].d=length;
          const a=points[Math.max(0,i-1)],b=points[Math.min(points.length-1,i+1)];
          const d=Math.hypot(b.x-a.x,b.y-a.y)||1;points[i].nx=-(b.y-a.y)/d;points[i].ny=(b.x-a.x)/d;
        }
        const original=1-smooth(progress/.26);
        if(original>.001&&this.renderer){
          ctx.save();ctx.globalAlpha*=original*route.opacity;
          this.renderer.options.color='#'+route.color.map(v=>v.toString(16).padStart(2,'0')).join('');
          this.renderer.time=this.snapshotTime+time*.3;
          this.renderer.renderStroke({points,route:{points,length},released:null,seed:route.seed},ctx);ctx.restore();
        }
        const transfer=smooth(progress/.24)*(1-smooth(formation/.4));
        if(transfer<.001)continue;
        const pieces=Math.max(1,Math.min(24,Math.ceil(length/70)));
        const violet=tint(route.color,[172,114,243],.65);
        for(let piece=0;piece<pieces;piece++){
          const lo=Math.floor(piece*(points.length-1)/pieces),hi=Math.max(lo+1,Math.floor((piece+1)*(points.length-1)/pieces));
          const seed=route.seed*17+piece*1.7;
          const delay=.035+.29*(piece/Math.max(1,pieces-1))+.055*rand(piece,route.seed+4);
          const travel=clamp((progress-delay)/(.98-delay));
          const flight=smooth(travel),opacity=transfer*route.opacity*(1-smooth((flight-.76)/.22));
          if(opacity<.001)continue;
          const source=points.slice(lo,Math.min(points.length,hi+1));
          const center=source[Math.floor(source.length*.5)],normal={x:center.nx,y:center.ny};
          const stream=smooth((flight-.08)/.45);
          // As a section lifts off, its transverse shape stretches into its
          // curved flight path. The moving tail is not a scaled copy of the ink.
          const strip=source.map((p,index)=>{
            const old=this.position(p,target,flight,seed,{x:p.nx,y:p.ny},time);
            const phase=index/Math.max(1,source.length-1);
            const tail=Math.max(0,flight-(1-phase)*(.22+.16*Math.sin(flight*Math.PI)));
            const flow=this.position(center,target,tail,seed,normal,time);
            return {x:old.x+(flow.x-old.x)*stream,y:old.y+(flow.y-old.y)*stream};
          });
          if(strip.length===1){
            this.glow(ctx,strip[0].x,strip[0].y,8*scale,colorTarget,.14*opacity);continue;
          }
          const color=tint(tint(violet,route.color,.45+.3*Math.sin(seed+time*.5)),colorTarget,colorMix);
          const thin=(1-flight*.65)*scale*widthScale;
          // Local soft layers stay transparent; the end of each stream disappears
          // before paths pile up at the center, avoiding an additive white flash.
          this.line(ctx,strip,18*thin*glowScale,color,.024*opacity*glowOpacity);
          this.line(ctx,strip,8*thin*glowScale,color,.095*opacity*glowOpacity);
          const pulse=.5+.5*Math.sin(seed-time*3);
          this.line(ctx,strip,2.6*thin,color,(.27+pulse*.14)*opacity);
          this.line(ctx,strip,.85*thin,color,(.53+pulse*.15)*opacity);
          if(strip.length>2){
            const shifted=strip.map((p,i)=>{
              const before=strip[Math.max(0,i-1)],after=strip[Math.min(strip.length-1,i+1)];
              const d=Math.hypot(after.x-before.x,after.y-before.y)||1;
              const offset=Math.sin(i*.48-time*2+seed)*2.7*scale*Math.sin(i/(strip.length-1)*Math.PI);
              return {x:p.x-(after.y-before.y)/d*offset,y:p.y+(after.x-before.x)/d*offset};
            });
            this.line(ctx,shifted,.6*thin,tint(color,[218,219,243],.2),.24*opacity);
          }
          const middle=strip[Math.floor(strip.length*.55)];
          this.glow(ctx,middle.x,middle.y,13*scale*(1-flight*.5),color,.08*opacity*glowOpacity);
        }
        const count=Math.min(route.motes,moteBudget);moteBudget-=count;
        for(let j=0;j<count;j++){
          const index=Math.min(points.length-1,Math.floor(rand(j,route.seed+30)*points.length));
          const p=points[index],seed=route.seed*13+j*2.71;
          const delay=.07+.33*rand(j,route.seed+8),flight=smooth((progress-delay)/(.99-delay));
          const alpha=Math.sin(Math.PI*clamp((progress-delay)/(.99-delay)))**2*.45*transfer*route.opacity;
          if(alpha<.002)continue;
          const q=this.position(p,target,flight,seed,{x:p.nx,y:p.ny},time);
          const color=tint(j%3?route.color:violet,colorTarget,colorMix);
          const radius=(.4+.5*rand(j,14))*scale*(1-flight*.4);
          ctx.fillStyle=rgba(color,alpha);ctx.beginPath();ctx.arc(q.x,q.y,radius,0,TAU);ctx.fill();
          if(j%8===0)this.glow(ctx,q.x,q.y,7*scale,color,.06*alpha);
        }
      }
      // A few low-energy arrival wisps bridge into the first material frame.
      const arrival=smooth((progress-.84)/.16)*(1-smooth(formation/.4));
      if(arrival>.001){
        for(let i=0;i<4;i++){
          const angle=i*TAU/4+time*.65,radius=(13+i*3)*scale*(1-formation*.8),pts=[];
          for(let j=0;j<=8;j++){
            const a=angle+j*.065,r=radius*(1-j*.035);
            pts.push({x:target.x+Math.cos(a)*r,y:target.y+Math.sin(a)*r*.55});
          }
          this.line(ctx,pts,.65*scale,colorTarget,.15*arrival);
          if(i%2===0)this.glow(ctx,pts[3].x,pts[3].y,8*scale,colorTarget,.035*arrival);
        }
      }
      ctx.restore();
    }
  }
  root.RevealGather=RevealGather;
})(globalThis);
