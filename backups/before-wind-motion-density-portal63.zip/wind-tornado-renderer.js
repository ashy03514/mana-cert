/* SS wind preview. The host owns time, pause, formation and the result.
 * A retained 2D frame keeps a paused WebGL drawing buffer from disappearing.
 */
(function(root){
  'use strict';
  const clamp=(v,min=0,max=1)=>Math.max(min,Math.min(max,v));
  const smooth=v=>{v=clamp(v);return v*v*(3-2*v);};
  const hash=n=>{const v=Math.sin(n*127.1+311.7)*43758.5453;return v-Math.floor(v);};
  class WindTornadoRenderer {
    constructor(createCanvas=()=>document.createElement('canvas')){
      this.canvas=createCanvas();this.patch=createCanvas();this.patchCtx=this.patch.getContext('2d');
      this.gl=null;this.program=null;this.buffer=null;this.uniforms={};
      this.error='';this.lost=false;this.disposed=false;this.time=0;
      this.lastTime=-Infinity;this.lastKey='';this.drawCount=0;this.renderBox=null;
      this.onLost=event=>{event.preventDefault();this.lost=true;this.error='龍捲風暫時中斷，正在等待恢復。';};
      this.onRestored=()=>{
        if(this.disposed)return;
        this.gl=null;this.program=null;this.buffer=null;this.lost=false;this.error='';
        this.lastTime=-Infinity;this.lastKey='';this.init();
      };
      this.canvas.addEventListener('webglcontextlost',this.onLost);
      this.canvas.addEventListener('webglcontextrestored',this.onRestored);
      this.init();
    }
    init(){
      if(this.lost||this.disposed||this.error)return false;
      if(this.program)return true;
      const shaders=[];let program=null;
      try{
        const gl=this.gl||this.canvas.getContext('webgl',{alpha:true,premultipliedAlpha:true,
          antialias:false,depth:false,stencil:false,preserveDrawingBuffer:false});
        if(!gl)throw Error('WebGL unavailable');
        this.gl=gl;
        for(const [type,source] of [[gl.VERTEX_SHADER,root.WindTornadoShader.vertex],[gl.FRAGMENT_SHADER,root.WindTornadoShader.fragment]]){
          const shader=gl.createShader(type);shaders.push(shader);gl.shaderSource(shader,source);gl.compileShader(shader);
          if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(shader));
        }
        program=gl.createProgram();shaders.forEach(shader=>gl.attachShader(program,shader));gl.linkProgram(program);
        if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));
        this.program=program;this.position=gl.getAttribLocation(program,'aPosition');
        for(const name of ['uTime','uAspect','uFormation'])this.uniforms[name]=gl.getUniformLocation(program,name);
        this.buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,this.buffer);
        gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),gl.STATIC_DRAW);
        gl.disable(gl.DEPTH_TEST);gl.disable(gl.BLEND);this.error='';return true;
      }catch(error){
        if(program)this.gl.deleteProgram(program);this.program=null;
        this.error='目前無法顯示龍捲風，請返回設定後重試。';this.diagnostic=String(error);return false;
      }finally{if(this.gl)shaders.forEach(shader=>this.gl.deleteShader(shader));}
    }
    layout(width,height){
      const h=Math.max(40,Math.min(height*.55,height-278,550));
      const w=Math.min(width*.96,h/1.34);
      return {x:(width-w)/2,y:54,width:w,height:w*1.34};
    }
    debris(ctx,box,time,formation,front){
      const unit=box.width/2,cx=box.x+unit,cy=box.y+box.height/2+.10*unit;
      for(let i=0;i<34;i++){
        const leaf=i<9,seed=i*17+11,period=3.5+hash(seed)*3.2;
        const h=(time/period+hash(seed+1))%1;
        const angle=time*(3.4-h*.8)+hash(seed+2)*Math.PI*2;
        const z=Math.sin(angle);if((z>=0)!==front)continue;
        const radius=.12+.55*Math.pow(h,1.4)+hash(seed+3)*.10;
        const spine=.10*Math.sin(h*4.2-time*.48)*h+.047*Math.sin(h*9.1+time*.67)*h*(1-h);
        const x=cx+(spine+Math.cos(angle)*radius)*unit;
        const y=cy-(-.83+h*1.75+z*.075)*unit;
        const alpha=smooth(h/.08)*(1-smooth((h-.83)/.17))*smooth((formation-h)/.2)*(.27+.26*(z+1)/2);
        if(alpha<.01)continue;
        ctx.save();ctx.globalAlpha*=alpha;ctx.translate(x,y);
        ctx.rotate(angle*.7+Math.sin(time*3+seed));
        const size=(leaf?1.2+hash(seed+4)*1.3:.45+hash(seed+4)*.7)*(box.width/360)*(.78+.22*z);
        ctx.fillStyle=leaf?(i%3===0?'#b8b592':'#8aab9e'):'#b5c7c7';
        if(leaf){
          const fold=.25+.75*Math.abs(Math.sin(time*4.2+seed));
          ctx.scale(1,fold);ctx.beginPath();ctx.moveTo(-size*1.6,0);
          ctx.quadraticCurveTo(0,-size,size*1.6,0);ctx.quadraticCurveTo(0,size*.65,-size*1.6,0);ctx.fill();
        }else{ctx.beginPath();ctx.ellipse(0,0,size*1.8,size*.5,0,0,Math.PI*2);ctx.fill();}
        ctx.restore();
      }
    }
    draw(ctx,_background,width,height,frame={}){
      if(!this.init())return false;
      frame=frame||{};
      const box=frame.box||this.layout(width,height);
      if(!(box.width>0&&box.height>0))return false;
      const time=Number.isFinite(frame.time)?Math.max(0,frame.time):0;
      const formation=clamp(frame.formation??1),opacity=clamp(frame.opacity??1);
      // Bound the raymarch surface on mobile and retain its exact aspect ratio.
      const scale=Math.min(1.25,root.devicePixelRatio||1,384/box.width,480/box.height);
      const pw=Math.max(1,Math.round(box.width*scale)),ph=Math.max(1,Math.round(box.height*scale));
      const key=[pw,ph,formation].join(':');this.time=time;this.renderBox={...box};
      if(key!==this.lastKey||time<this.lastTime||time-this.lastTime>=1/30-1e-6){
        if(this.canvas.width!==pw||this.canvas.height!==ph){
          this.canvas.width=this.patch.width=pw;this.canvas.height=this.patch.height=ph;
        }
        const gl=this.gl;gl.viewport(0,0,pw,ph);gl.useProgram(this.program);
        gl.bindBuffer(gl.ARRAY_BUFFER,this.buffer);gl.enableVertexAttribArray(this.position);
        gl.vertexAttribPointer(this.position,2,gl.FLOAT,false,0,0);
        gl.uniform1f(this.uniforms.uTime,time);gl.uniform1f(this.uniforms.uAspect,box.height/box.width);
        gl.uniform1f(this.uniforms.uFormation,formation);
        gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT);gl.drawArrays(gl.TRIANGLES,0,6);
        this.patchCtx.clearRect(0,0,pw,ph);this.patchCtx.drawImage(this.canvas,0,0);
        this.lastTime=time;this.lastKey=key;this.drawCount++;
      }
      ctx.save();ctx.globalCompositeOperation='source-over';ctx.globalAlpha=opacity;
      this.debris(ctx,box,this.lastTime,formation,false);
      ctx.drawImage(this.patch,box.x,box.y,box.width,box.height);
      this.debris(ctx,box,this.lastTime,formation,true);ctx.restore();return true;
    }
    dispose(){
      if(this.disposed)return;
      this.disposed=true;
      this.canvas.removeEventListener('webglcontextlost',this.onLost);
      this.canvas.removeEventListener('webglcontextrestored',this.onRestored);
      if(this.gl&&!this.lost){this.gl.deleteProgram(this.program);this.gl.deleteBuffer(this.buffer);}
      this.program=null;this.buffer=null;this.gl=null;this.lastTime=-Infinity;
      this.canvas.width=this.canvas.height=this.patch.width=this.patch.height=1;
    }
  }
  root.WindTornadoRenderer=WindTornadoRenderer;
})(globalThis);
