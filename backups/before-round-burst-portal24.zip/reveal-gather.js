/* Drawn ribbons become depth-sorted orbs: burst, suspended drift, then implosion.
 * This layer owns only an immutable drawing snapshot, never input or reveal state. */
(function(root){
  'use strict';
  const TAU=Math.PI*2;
  const clamp=(v,a=0,b=1)=>Math.min(b,Math.max(a,v));
  const smooth=v=>{v=clamp(v);return v*v*(3-2*v);};
  const finite=(v,fallback=0)=>Number.isFinite(v)?v:fallback;
  const rand=(i,s=0)=>{const n=Math.sin(i*127.1+s*311.7)*43758.5453;return n-Math.floor(n);};
  const rgb=hex=>/^#[0-9a-f]{6}$/i.test(hex||'')?[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)):[125,234,255];
  const tint=(a,b,t)=>a.map((n,i)=>Math.round(n+(b[i]-n)*clamp(t)));
  const rgba=(c,a)=>'rgba('+c.join(',')+','+clamp(a)+')';
  const palettes={fire:[244,170,83],water:[118,218,237],wind:[192,216,183],
    earth:[195,169,116],light:[246,231,192],dark:[171,118,225]};
  class RevealGather {
    constructor(){
      this.width=0;this.height=0;this.routes=[];this.pointCount=0;this.moteCount=0;
      this.maxPoints=1600;this.maxMotes=180;this.snapshotTime=0;this.opacity=1;
      this.renderer=null;this.options={};
      this.orbs=Object.freeze([]);
    }
    resize(width,height){
      if(Number.isFinite(width)&&Number.isFinite(height)&&width>0&&height>0){
        this.width=width;this.height=height;
      }
    }
    capture(trails,width,height){
      this.routes=[];this.pointCount=0;this.moteCount=0;this.orbs=Object.freeze([]);
      this.resize(width||trails?.width,height||trails?.height);
      if(!trails||!this.width||!this.height||trails.settings?.trailEnabled===false)return;
      this.snapshotTime=finite(trails.time);
      this.options={...trails.renderer?.options};
      this.opacity=clamp(finite(trails.settings?.trailOpacity,100)/100);
      this.renderer=root.RibbonRenderer?new root.RibbonRenderer(this.options):null;
      // Asking the live renderer for a route would mutate its geometry cache.
      // Work on a copy, including for strokes whose route has not been built yet.
      const visible=(trails.strokes||[]).filter(s=>s.points?.length&&
        (typeof trails.opacity==='function'?trails.opacity(s):1)>.03).slice(-16);
      const candidates=visible.map((s,index)=>{
        const points=s.points.filter(p=>Number.isFinite(p.x)&&Number.isFinite(p.y)).map(p=>({
          x:p.x,y:p.y,speed:finite(p.speed,.5)
        }));
        if(!points.length)return null;
        const copy={points,seed:finite(s.seed,index),released:null,sampleBudget:1600};
        let route=this.renderer?.route(copy);
        if(!route){
          let length=0;
          route={points:points.map((p,i)=>{
            if(i)length+=Math.hypot(p.x-points[i-1].x,p.y-points[i-1].y);
            return {...p,d:length,nx:0,ny:1};
          }),length};route.length=length;
        }
        return {route,seed:copy.seed,color:rgb(s.color),
          opacity:clamp(typeof trails.opacity==='function'?finite(trails.opacity(s),1):1),
          weight:Math.max(8,route.length)};
      }).filter(Boolean);
      const sum=candidates.reduce((n,s)=>n+s.weight,0);
      let remaining=this.maxPoints;
      candidates.forEach((s,index)=>{
        const budget=Math.min(remaining-(candidates.length-index-1)*2,
          Math.max(2,Math.floor(this.maxPoints*s.weight/(sum||1))));
        const count=s.route.length<1?1:Math.min(budget,Math.max(2,Math.ceil(s.route.length/3.5)+1));
        const sample=(d)=>{
          if(this.renderer)return this.renderer.at(s.route,d);
          const source=s.route.points;
          let i=1;while(i<source.length-1&&source[i].d<d)i++;
          if(source.length===1)return source[0];
          const a=source[i-1],b=source[i],f=clamp((d-a.d)/Math.max(.001,b.d-a.d));
          return {x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f,nx:0,ny:1};
        };
        const points=Array.from({length:count},(_,i)=>{
          const p=sample(s.route.length*i/Math.max(1,count-1));
          return Object.freeze({x:p.x/this.width,y:p.y/this.height,speed:.5});
        });
        const route=Object.freeze({points:Object.freeze(points),seed:s.seed,color:Object.freeze(s.color),
          opacity:s.opacity,motes:Math.max(2,Math.ceil(s.route.length/10))});
        this.routes.push(route);this.pointCount+=count;remaining-=count;
      });
      const demand=this.routes.reduce((n,s)=>n+s.motes,0),orbs=[];
      let available=this.maxMotes;
      this.routes.forEach((route,index)=>{
        const count=Math.min(available,Math.max(1,Math.floor(route.motes*Math.min(1,this.maxMotes/demand))));
        for(let i=0;i<count;i++){
          // Stratified samples keep the complete drawing represented, without
          // making cut-up chunks of its geometry visible for even one frame.
          const seed=route.seed*19+index*107+i*2.73;
          const along=clamp((i+.2+.6*rand(seed,2))/count)*(route.points.length-1);
          const lo=Math.floor(along),hi=Math.min(lo+1,route.points.length-1),f=along-lo;
          const a=route.points[lo],b=route.points[hi];
          orbs.push(Object.freeze({
            x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f,
            depth:rand(seed,3)*2-1,seed,route:index,
            size:2.9+rand(seed,4)*2.1,
            opacity:route.opacity*(.75+.2*rand(seed,5))
          }));
        }
        available-=count;
      });
      this.orbs=Object.freeze(orbs);this.moteCount=orbs.length;
      Object.freeze(this.routes);
    }
    line(ctx,points,width,color,opacity){
      if(points.length<2||opacity<.001)return;
      ctx.lineWidth=Math.max(.2,width);ctx.strokeStyle=rgba(color,opacity);
      ctx.beginPath();ctx.moveTo(points[0].x,points[0].y);
      for(let i=1;i<points.length;i++)ctx.lineTo(points[i].x,points[i].y);
      ctx.stroke();
    }
    glow(ctx,x,y,radius,color,opacity){
      if(opacity<.001)return;
      const g=ctx.createRadialGradient(x,y,0,x,y,radius);
      g.addColorStop(0,rgba(color,opacity));g.addColorStop(.3,rgba(color,opacity*.42));g.addColorStop(1,rgba(color,0));
      ctx.fillStyle=g;ctx.fillRect(x-radius,y-radius,radius*2,radius*2);
    }
    orbit(orb,target,scale){
      const x=orb.x*this.width-target.x,y=orb.y*this.height-target.y;
      const distance=Math.hypot(x,y),fallback=rand(orb.seed,7)*TAU;
      const angle=(distance>2?Math.atan2(y,x):fallback)+(rand(orb.seed,8)-.5)*.65;
      const push=(48+rand(orb.seed,9)*60)*scale;
      // Choose the projected destination first, so distant orbs also burst
      // outward instead of apparently moving inward as perspective decreases.
      // Let edge-born orbs move beyond the viewport. Clamping each axis would
      // arrange their destinations into an artificial rectangular border.
      const endX=x+Math.cos(angle)*push,endY=y+Math.sin(angle)*push;
      const perspective=1/(1-orb.depth*.5);
      const px=endX/perspective,py=endY/perspective;
      const d=Math.hypot(px,py)||1,side=rand(orb.seed,10)>.5?1:-1;
      return {x,y,px,py,nx:-py/d*side,ny:px/d*side,
        bend:(18+rand(orb.seed,11)*32)*scale,
        // Arrival is slightly spread, while every orb starts the burst together.
        end:.965+.035*rand(orb.seed,12),depth:orb.depth,seed:orb.seed};
    }
    position(path,progress,target){
      progress=clamp(progress);
      const pullStart=2/3;
      let x,y,z,pull=0;
      if(progress<=pullStart){
        const burst=progress<.1?.78*(1-(1-progress/.1)**3):
          .78+.22*smooth((progress-.1)/(pullStart-.1));
        const drift=Math.sin(Math.PI*clamp((progress-.1)/(pullStart-.1)));
        const sway=drift*4*Math.sin(path.seed+progress*6);
        x=path.x+(path.px-path.x)*burst+path.nx*sway;
        y=path.y+(path.py-path.y)*burst+path.ny*sway;
        z=path.depth*burst;
      }else{
        const phase=clamp((progress-pullStart)/(path.end-pullStart));
        pull=phase**2.35;
        const u=1-pull;
        const c1x=path.px+path.nx*path.bend,c1y=path.py+path.ny*path.bend;
        const c2x=path.px*.12+path.nx*path.bend*.65,c2y=path.py*.12+path.ny*path.bend*.65;
        x=u*u*u*path.px+3*u*u*pull*c1x+3*u*pull*pull*c2x;
        y=u*u*u*path.py+3*u*u*pull*c1y+3*u*pull*pull*c2y;
        z=path.depth*(1-pull);
      }
      const perspective=1/(1-z*.5);
      return {x:target.x+x*perspective,y:target.y+y*perspective,
        z,perspective,pull,alpha:1-smooth((pull-.75)/.24)};
    }
    ball(ctx,p,radius,color,opacity,glowScale,glowOpacity){
      if(opacity<.002)return;
      const near=smooth((p.z-.2)/.8),core=tint(color,[247,250,255],.8);
      this.glow(ctx,p.x,p.y,radius*(2.8+near)*glowScale,color,.19*opacity*glowOpacity);
      // A soft luminous volume with a small off-centre highlight. Foreground
      // volumes have a broader edge, rather than a large opaque white centre.
      const r=radius*(1+near*.22);
      const g=ctx.createRadialGradient(p.x-r*.16,p.y-r*.2,0,p.x,p.y,r);
      g.addColorStop(0,rgba(core,opacity*(.92-near*.2)));
      g.addColorStop(.2,rgba(tint(color,core,.6),opacity*.85));
      g.addColorStop(.47,rgba(color,opacity*.57));
      g.addColorStop(.74,rgba(color,opacity*.2));
      g.addColorStop(1,rgba(color,0));
      ctx.fillStyle=g;ctx.fillRect(p.x-r,p.y-r,r*2,r*2);
    }
    tail(ctx,points,radius,color,opacity){
      const first=points[0],last=points.at(-1);
      const gradient=ctx.createLinearGradient(first.x,first.y,last.x,last.y);
      gradient.addColorStop(0,rgba(color,0));
      gradient.addColorStop(.4,rgba(color,opacity*.14));
      gradient.addColorStop(1,rgba(color,opacity*.52));
      const edges=points.map((p,i)=>{
        const a=points[Math.max(0,i-1)],b=points[Math.min(points.length-1,i+1)];
        const length=Math.hypot(b.x-a.x,b.y-a.y)||1,t=i/(points.length-1);
        const half=Math.max(.08,radius*.4*t);
        return {x:p.x,y:p.y,nx:-(b.y-a.y)/length*half,ny:(b.x-a.x)/length*half};
      });
      // One tapered silhouette avoids the bright seams produced by overlapping
      // round caps when a tail is drawn as many short independent strokes.
      ctx.fillStyle=gradient;ctx.beginPath();
      ctx.moveTo(edges[0].x+edges[0].nx,edges[0].y+edges[0].ny);
      for(let i=1;i<edges.length;i++)ctx.lineTo(edges[i].x+edges[i].nx,edges[i].y+edges[i].ny);
      for(let i=edges.length-1;i>=0;i--)ctx.lineTo(edges[i].x-edges[i].nx,edges[i].y-edges[i].ny);
      ctx.closePath();ctx.fill();
    }
    draw(ctx,{progress=0,formation=0,width=this.width,height=this.height,target,element='fire',time=0}={}){
      if(!ctx||!this.routes.length)return;
      this.resize(width,height);width=this.width;height=this.height;
      progress=clamp(finite(progress));formation=clamp(finite(formation));time=finite(time);
      if(!width||!height||formation>=.4)return;
      target={x:finite(target?.x,width/2),y:finite(target?.y,height*.5)};
      const colorTarget=palettes[element]||palettes.fire,colorMix=smooth((progress-.68)/.29);
      const scale=clamp(Math.min(width,height)/390,.65,1.6),widthScale=clamp(finite(this.options.width,1),.3,3);
      const glowScale=clamp(finite(this.options.glowSize,1),.25,2);
      const glowOpacity=clamp(finite(this.options.glowOpacity,1),0,2);
      ctx.save();ctx.globalCompositeOperation='source-over';ctx.lineCap='round';ctx.lineJoin='round';
      ctx.globalAlpha=this.opacity;
      const original=1-smooth(progress/.055),transfer=smooth(progress/.025)*(1-smooth(formation/.3));
      // Only the unbroken original silhouette is rendered during the first
      // ~80 ms. The next layer is already made of spheres, never line sections.
      if(original>.001&&this.renderer)for(const route of this.routes){
        const points=route.points.map(p=>({x:p.x*width,y:p.y*height,speed:p.speed}));
        let length=0;
        for(let i=0;i<points.length;i++){
          if(i)length+=Math.hypot(points[i].x-points[i-1].x,points[i].y-points[i-1].y);
          points[i].d=length;
          const a=points[Math.max(0,i-1)],b=points[Math.min(points.length-1,i+1)];
          const d=Math.hypot(b.x-a.x,b.y-a.y)||1;points[i].nx=-(b.y-a.y)/d;points[i].ny=(b.x-a.x)/d;
        }
        ctx.save();ctx.globalAlpha*=original*route.opacity;
        this.renderer.options.color='#'+route.color.map(v=>v.toString(16).padStart(2,'0')).join('');
        this.renderer.time=this.snapshotTime;
        this.renderer.renderStroke({points,route:{points,length},released:this.snapshotTime,seed:route.seed},ctx);ctx.restore();
      }
      const bodies=this.orbs.map(orb=>{
        const route=this.routes[orb.route],path=this.orbit(orb,target,scale),p=this.position(path,progress,target);
        const color=tint(tint(route.color,[172,130,243],rand(orb.seed,14)*.65),colorTarget,colorMix);
        const radius=orb.size*scale*Math.sqrt(widthScale)*p.perspective*(1-p.pull*.62);
        return {orb,path,p,color,radius,alpha:orb.opacity*transfer*p.alpha*(.78+.22*smooth((p.z+1)/2))};
      }).sort((a,b)=>a.p.z-b.p.z);
      // Trails sample the same continuous 3D path as their heads. Suspended
      // orbs have virtually no tail; rapid inward travel stretches into a curve.
      for(const {path,p,color,radius,alpha} of bodies){
        if(alpha<.002)continue;
        const lookback=progress>2/3?.055:progress<.12?.018:.008;
        const tail=[];
        for(let j=0;j<=8;j++)tail.push(this.position(path,Math.max(0,progress-lookback*(1-j/8)),target));
        const span=Math.hypot(tail[0].x-p.x,tail[0].y-p.y);
        if(span<2)continue;
        const strength=smooth(span/18)*alpha;
        this.line(ctx,tail,radius*3*glowScale,color,.024*strength*glowOpacity);
        this.tail(ctx,tail,radius,color,strength);
      }
      for(const {p,color,radius,alpha} of bodies){
        this.ball(ctx,p,radius,color,alpha,glowScale,glowOpacity);
      }
      // A few low-energy arrival wisps bridge into the first material frame.
      const arrival=smooth((progress-.84)/.16)*(1-smooth(formation/.4));
      if(arrival>.001){
        for(let i=0;i<4;i++){
          const angle=i*TAU/4+time*.65,radius=(13+i*3)*scale*(1-formation*.8),pts=[];
          for(let j=0;j<=8;j++){
            const a=angle+j*.065,r=radius*(1-j*.035);
            pts.push({x:target.x+Math.cos(a)*r,y:target.y+Math.sin(a)*r*.55});
          }
          this.line(ctx,pts,.65*scale,colorTarget,.15*arrival);
          if(i%2===0)this.glow(ctx,pts[3].x,pts[3].y,8*scale,colorTarget,.035*arrival);
        }
      }
      ctx.restore();
    }
  }
  root.RevealGather=RevealGather;
})(globalThis);
