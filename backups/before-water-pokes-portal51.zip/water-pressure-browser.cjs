'use strict';
// Read the opaque liquid silhouette from real WebGL frames. These checks
// distinguish changing pressure bulges from a rigidly spinning round sphere.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {chromium}=require(process.env.MANA_PLAYWRIGHT_MODULE||'C:/Users/ashy0/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const {createCanvas,loadImage}=require(process.env.MANA_CANVAS_MODULE||'C:/Users/ashy0/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas');
const root=path.resolve(__dirname,'..'),read=p=>fs.readFileSync(path.join(root,p),'utf8');
const mean=a=>a.reduce((s,v)=>s+v,0)/a.length;
function roughness(rays){
  const residual=[];
  for(let i=0;i<rays.length;i++){
    const a=rays[(i+rays.length-4)%rays.length],b=rays[(i+4)%rays.length],c=rays[i];
    if(a!==null&&b!==null&&c!==null)residual.push(Math.abs(c-(a+b)/2));
  }
  return mean(residual);
}
function nonRigid(a,b){
  let best=Infinity;
  for(let shift=0;shift<a.length;shift++){
    const diffs=[];
    for(let i=0;i<a.length;i++)if(a[i]!==null&&b[(i+shift)%b.length]!==null)diffs.push(a[i]-b[(i+shift)%b.length]);
    const offset=mean(diffs);
    best=Math.min(best,Math.sqrt(mean(diffs.map(d=>(d-offset)**2))));
  }
  return best;
}
(async()=>{
  const browser=await chromium.launch({headless:true,executablePath:process.env.MANA_CHROME||'C:/Program Files/Google/Chrome/Application/chrome.exe',args:['--enable-unsafe-swiftshader','--use-angle=swiftshader']});
  const errors=[],results=[];
  try{
    async function setup(baseline){
      const page=await browser.newPage({viewport:{width:390,height:844}});
      page.on('pageerror',e=>errors.push(String(e)));
      await page.setContent('<canvas id="scene"></canvas>');
      await page.addScriptTag({content:read('js/fire-scan-transition.js')});
      for(const name of ['element-material-fluids.js','element-material-renderer.js'])await page.addScriptTag({content:read((baseline?'artifacts/water-pressure-baseline/':'js/')+name)});
      await page.evaluate(()=>{
        window.r=new ElementMaterialRenderer();r.select('water');
        window.paint=({width,height,power,time,center})=>{
          const c=document.querySelector('canvas');c.width=width;c.height=height;const ctx=c.getContext('2d');
          ctx.fillStyle='#061522';ctx.fillRect(0,0,width,height);
          const layout=FireScanTransition.layout(width,height,r.layout(width,height),1),box=layout.box;
          const ok=r.draw(ctx,c,width,height,{time,waterPower:power,formation:1,phase:.5,opacity:1,box});
          const p=r.patch,b=r.renderBox,pw=p.width,ph=p.height,data=r.patchCtx.getImageData(0,0,pw,ph).data;
          const sx=b.width/pw,sy=b.height/ph,rootY=box.y+box.height/2+box.width*.33;
          // Keep the largest connected dense component; detached droplets
          // cannot count as swelling of the main liquid body.
          const seen=new Uint8Array(pw*ph);let body=[];
          for(let start=0;start<seen.length;start++){
            if(seen[start]||data[start*4+3]<150)continue;
            const stack=[start],part=[];seen[start]=1;
            while(stack.length){
              const i=stack.pop(),x=i%pw,y=Math.floor(i/pw);part.push(i);
              for(const [dx,dy] of [[-1,0],[1,0],[0,-1],[0,1]]){
                const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=pw||ny>=ph)continue;
                const n=ny*pw+nx;if(!seen[n]&&data[n*4+3]>=150){seen[n]=1;stack.push(n);}
              }
            }
            if(part.length>body.length)body=part;
          }
          const mask=new Uint8Array(pw*ph);let top=Infinity,bottom=-Infinity,left=Infinity,right=-Infinity;
          for(const i of body){mask[i]=1;const x=b.x+(i%pw+.5)*sx,y=b.y+(Math.floor(i/pw)+.5)*sy;
            top=Math.min(top,y);bottom=Math.max(bottom,y);left=Math.min(left,x);right=Math.max(right,x);}
          center=center||{x:box.x+box.width/2,y:(top+Math.min(bottom,rootY))/2};
          const rays=[];
          for(let i=0;i<120;i++){
            const a=i*Math.PI*2/120;let distance=0,clipped=false;
            for(let rad=0;rad<width;rad+=.5){
              const x=Math.floor((center.x+Math.cos(a)*rad-b.x)/sx),y=Math.floor((center.y+Math.sin(a)*rad-b.y)/sy);
              if(x<2||x>=pw-2||y<2||y>=ph-2){clipped=true;break;}
              if(!mask[y*pw+x])break;distance=rad;
            }
            rays.push(clipped?null:distance);
          }
          let patchHash=2166136261;for(const byte of data)patchHash=Math.imul(patchHash^byte,16777619);
          const final=ctx.getImageData(0,0,width,height).data;let hash=2166136261;
          for(const byte of final)hash=Math.imul(hash^byte,16777619);
          return {ok,error:r.error,diagnostic:r.diagnostic,gl:r.gl.getError(),hash:hash>>>0,patchHash:patchHash>>>0,center,rays,
            rootY,top,bottom,left,right,area:body.length*sx*sy,titleY:layout.numbers.labelY-layout.numbers.labelFontSize-13,
            scene:c.toDataURL()};
        };
      });return page;
    }
    const baseline=await setup(true),current=await setup(false);
    const paint=(page,args)=>page.evaluate(args=>paint(args),args);
    for(const power of [0,1,1.94,2.4]){
      for(const time of [1.6,3.4]){
        const args={width:390,height:844,power,time},before=await paint(baseline,args),after=await paint(current,args);
        assert.ok(after.ok,after.error+' '+after.diagnostic);assert.equal(after.gl,0);
        assert.equal(after.hash,before.hash,'non-SS visible water pixels stay unchanged');
      }
    }
    const images=[];
    for(const [width,height] of [[390,844],[320,568]]){
      const frames=[];
      for(const time of [1.6,2.3,3.4]){
        const args={width,height,power:3,time},before=await paint(baseline,args),after=await paint(current,{...args,center:before.center});
        assert.ok(after.ok,after.error+' '+after.diagnostic);assert.equal(after.gl,0);
        assert.ok(after.area>before.area*.70,'pressurized water remains a substantial cohesive volume');
        assert.ok(after.bottom<after.titleY-8,'water body leaves the attribute title clear');
        const rb=roughness(before.rays),ra=roughness(after.rays);
        assert.ok(ra>rb*1.5&&ra>1,'SS silhouette has clear, distributed pressure bulges');
        const deltas=after.rays.map((r,i)=>r===null||before.rays[i]===null?null:r-before.rays[i]).filter(v=>v!==null);
        assert.ok(Math.max(...deltas)>2,'some liquid pushes outward beyond the formerly round sphere');
        const repeat=await paint(current,{...args,center:before.center});assert.equal(repeat.patchHash,after.patchHash,'paused pressure shape stays pixel-identical');
        results.push({width,height,time,beforeRoughness:rb,afterRoughness:ra,maxPush:Math.max(...deltas),top:after.top,bottom:after.bottom,titleY:after.titleY});
        frames.push(after);if(width===390)images.push(after.scene);
      }
      const evolution=nonRigid(frames[0].rays,frames[2].rays);
      assert.ok(evolution>1,'pressure shape swells unevenly rather than rotating rigidly');
      results.push({width,height,nonRigidEvolution:evolution});
    }
    assert.deepEqual(errors,[]);
    const sheet=createCanvas(390*3,844),ctx=sheet.getContext('2d');
    for(let i=0;i<images.length;i++)ctx.drawImage(await loadImage(images[i]),i*390,0);
    fs.mkdirSync(path.join(root,'artifacts'),{recursive:true});
    fs.writeFileSync(path.join(root,'artifacts/water-pressure-motion.png'),sheet.toBuffer('image/png'));
    fs.writeFileSync(path.join(root,'artifacts/water-pressure-motion.json'),JSON.stringify(results,null,2));
    console.log('water pressure GPU silhouette / non-rigid motion / pause / text clearance / lower-rank regression passed',JSON.stringify(results));
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
