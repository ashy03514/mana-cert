# SS 水之星球：美術動畫樣板

入口：`water-ocean-study.html`。這是單獨的第一階段樣板，正式鑑定仍維持 portal 52。

## 這版要確認的視覺方向

- 移除前方兩道交會浪冠、碰撞水花與週期性交鋒演出，先集中調整球體本身的海洋材質。
- 以真實海水參考中的深藍浪谷、不同尺度的連續起伏、破碎白沫與天空反射為美術方向。海面流動沿球面分布，不再以幾條凸出的規則浪帶作為主體。
- 白沫集中在局部浪峰並隨水流變化；保留深色水體，讓細小起伏與反光有可辨識的層次。
- 使用生成的寫實海面細節素材，配合持續變化的球面幾何、表面法線、流動取樣與反光。這是美術材質動畫，不是真實流體模擬；靜態素材負責細節，動畫仍由共用時間驅動。
- 目前仍是即時材質樣板。桌面檢查只確認動畫、控制與版面運作；海水的自然度與參考圖的接近程度仍需視覺確認，再延伸到 E–S。

## 操作

- 暫停／繼續、重新播放。
- 播放速度：0.5×、1×、1.5×。
- 海面風浪：調整海面的起伏與材質表現。
- 切換至背景會停止動畫時間；暫停中調整尺寸或強度會保留時間重畫。

## 檔案與介面

- `js/water-ocean-study.js`：`WaterOceanStudy(canvas)`，使用單一海面 WebGL program 與球面網格，已移除浪冠與碰撞水花 program。使用有上限的渲染尺寸，無第三方依賴。
- `js/ocean-surface-shader.js`：海面幾何、法線、色彩、細節素材與反光的 shader。
- `assets/ocean-surface-v1.webp`：生成的海面細節素材。`renderer.ready` 在素材載入完成後結束，`textureReady` 可檢查載入狀態；預覽應透過 HTTP 開啟以供 WebGL 同源取樣。
- `water-ocean-study.html`：獨立播放時鐘、控制、錯誤訊息、手機直橫式版面。
- `window.waterOceanStudy.renderAt(seconds)`：定格於指定時間，供畫格檢查；`pause(boolean)` 控制播放，`dispose()` 釋放資源。
- 不接觸正式結果抽選、機率、現有火／水成長或 service worker。

## 驗證

`node tests/water-ocean-study-browser.cjs`

測試自行啟動僅監聽 `127.0.0.1` 的臨時唯讀 HTTP 伺服器，結束後關閉。檢查素材成功載入、實際海面 shader 編譯與 WebGL 錯誤、交鋒 program 已移除、非空動畫畫面、同時間像素一致、時間推進、暫停／重播／速度／強度、頁面隱藏與恢復、暫停時改變尺寸，以及 390×844、320×568、844×390 的畫面與控制區淨空。此檢查驗證桌面 Chrome；手機 PWA 的觀感與效能另行確認。

實際畫格：`artifacts/ocean-study-portrait.png`、`artifacts/ocean-study-small.png`、`artifacts/ocean-study-landscape.png`。

### 長時間播放材質拉伸修正

海流旋轉原本只作用在取樣座標，三平面貼圖混合仍使用未旋轉的球面方向；轉到側向時會選到幾乎側對視線的投影，將白沫拉成橫條。現在取樣座標與投影權重共用同一個旋轉座標系，保留原有海面素材、起伏、反光與播放節奏。

GPU 回歸測試取樣 0、56、112、224、336、449、1800 秒，檢查球面前方仍保有水平與垂直細節，避免旋轉約四分之一圈後退化成條紋。這是指定時間取樣，不是連續播放 30 分鐘。修正前後畫格對照：`artifacts/ocean-projection-before.png`、`artifacts/ocean-projection-after.png`。此輪修改前 shader 保留在 `backups/ocean-surface-before-projection-fix.js`。

## 素材與技術參考

- 海面細節由 imagegen 生成，依照使用者提供的真實海水照片方向製作；WebP 約 666 KiB。原始生成圖保留在 `assets/ocean-surface-v1.png`。
- 大尺度幾何與小尺度法線分層的水面做法參考 [GPU Gems：Effective Water Simulation from Physical Models](https://developer.nvidia.com/gpugems/gpugems/part-i-natural-effects/chapter-1-effective-water-simulation-physical-models)。本專案的球面座標、海面細節投影、材質與生命週期為獨立實作。
- 此輪修改前備份：`backups/before-ocean-surface-study.zip`。
