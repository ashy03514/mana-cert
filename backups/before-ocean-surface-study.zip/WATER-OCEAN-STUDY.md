# SS 水之星球：美術動畫樣板

入口：`water-ocean-study.html`。這是單獨的第一階段樣板，正式鑑定仍維持 portal 52。

## 這版要確認的視覺方向

- 球形主體承載兩股不同傾角、速度與方向的海潮。表面有實際幾何起伏，水流與緩慢自轉分開取樣。
- 前方兩道浪冠逐漸接近、抬起、翻捲，再落回球面。浪冠用獨立曲面形成切向卷唇，與海面共用深度遮擋及水色。
- 海浪峰頂生成青白泡沫，細小白沫與水紋以不同速度散開。深藍浪谷保留大面積暗部；高光與泡沫不是整片發光。
- 碰撞時短暫產生水珠，離開浪尖後落回；海潮持續運動。每輪約 3.7 秒，位置與傾角逐輪變化。
- 這是程序化即時材質的第一版，尚未達到參考圖中攝影級海浪的細節。下一次美術調整應優先看浪冠的形狀、白沫密度與交鋒節奏，再延伸到 E–S。

## 操作

- 暫停／繼續、重新播放。
- 播放速度：0.5×、1×、1.5×。
- 海潮強度：調整表面起伏、浪冠抬升與水珠強度。
- 切換至背景會停止動畫時間；暫停中調整尺寸或強度會保留時間重畫。

## 檔案與介面

- `js/water-ocean-study.js`：`WaterOceanStudy(canvas)`，持有三個 WebGL program、球面與浪冠網格、水珠緩衝。使用有上限的渲染尺寸，無第三方依賴。
- `water-ocean-study.html`：獨立播放時鐘、控制、錯誤訊息、手機直橫式版面。
- `window.waterOceanStudy.renderAt(seconds)`：定格於指定時間，供畫格檢查；`pause(boolean)` 控制播放，`dispose()` 釋放資源。
- 不接觸正式結果抽選、機率、現有火／水成長或 service worker。

## 驗證

`node tests/water-ocean-study-browser.cjs`

檢查實際 shader 編譯與 WebGL 錯誤、非空動畫畫面、同時間像素一致、時間推進、暫停／重播／速度／強度、頁面隱藏與恢復、暫停時改變尺寸，以及 390×844、320×568、844×390 的畫面與控制區淨空。此檢查驗證桌面 Chrome；手機 PWA 的觀感與效能另行確認。

實際畫格：`artifacts/ocean-study-portrait.png`、`artifacts/ocean-study-small.png`、`artifacts/ocean-study-landscape.png`。
