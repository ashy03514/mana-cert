const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
require('../js/config.js');
require('../js/effect-settings.js');
require('../js/ribbon-renderer.js');
require('../js/finger-trails.js');
require('../js/probability-settings.js');
require('../js/result-system.js');
require('../js/portal-scene.js');
require('../js/runtime.js');
require('../js/audio.js');
require('../js/element-material-renderer.js');
require('../js/reveal-flow.js');
require('../js/reveal-gather.js');
require('../js/reveal-atmosphere.js');
const C = {...ManaConfig}, R = ManaResults;
const settings = { elements:Object.fromEntries(Object.keys(C.elementWeights).map(k=>[k,true])), muggleEnabled:true, muggleChance:0.08 };
function rng(values) { let i=0; return () => { assert.ok(i<values.length,'unexpected additional random draw'); return values[i++]; }; }
assert.deepEqual(R.createResult(settings,rng([0.079,0])),{type:'muggle',element:null,rank:'MUGGLE',mana:1});
assert.equal(R.createResult(settings,rng([0,0.999999])).mana,9);
assert.equal(R.createResult(settings,rng([0.08,0,0.999,0])).rank,'E');
assert.equal(R.createResult(settings,rng([0.08,0,0.999,0])).mana,10);
for(const element of Object.keys(C.elementWeights)) {
  const single = {...settings,muggleEnabled:false,elements:{[element]:true}};
  const weights = element==='光'||element==='暗' ? C.rareElementRanks : C.normalRanks;
  let offset=0;
  for(const [rank,weight] of Object.entries(weights)) {
    for(const edge of [0,0.999999]) {
      const result=R.createResult(single,rng([0,offset+weight/2,edge]));
      assert.equal(result.element,element); assert.equal(result.rank,rank);
      assert.equal(result.mana,C.ranks[rank].range[edge===0?0:1]);
      assert.ok(Object.isFrozen(result));
    }
    offset+=weight;
  }
}
assert.equal(R.validSettings({...settings,elements:{}}),false);
assert.equal(R.validSettings({...settings,elements:{},muggleChance:1}),true);
assert.equal(R.validSettings({...settings,muggleChance:NaN}),false);
assert.throws(()=>R.createResult({...settings,elements:{}}));
for(const [n,rank] of [[1,'E'],[199,'E'],[200,'D'],[350,'C'],[550,'B'],[750,'A'],[900,'S'],[9999,'S']]) assert.equal(R.rankForNumber(n),rank);
const session = new R.Session();
session.begin(settings,rng([0,0.6])); const result=session.currentResult;
for(const state of ['INTERACTION','RESONANCE_COMPLETE','GATHER','ELEMENT_REVEAL','MANA_SCAN','RANK_CONFIRM','RESULT']) session.transition(state);
assert.equal(session.currentResult,result); assert.throws(()=>session.transition('INTERACTION'));
session.reset(); assert.equal(session.currentResult,null); assert.equal(session.state,'SETTINGS');

// Run the real page without launching a browser. Device appearance remains a manual check.
const html=fs.readFileSync('index.html','utf8');
const script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const htmlIds=new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]));
const imports=[...html.matchAll(/<script\b[^>]*\bsrc="([^"]+)"/g)].map(m=>m[1]);
for(const oldId of ['guideText','coreCanvas','fxCanvas','elementRevealScene'])assert.ok(!htmlIds.has(oldId),'retired visual node: '+oldId);
for(const oldModule of ['magic-interaction','standby-magic','particle-renderer','resonance','ritual-renderer','element-effects'])assert.ok(!imports.includes('./js/'+oldModule+'.js'),'retired renderer is not loaded: '+oldModule);
assert.ok(imports.includes('./js/portal-scene.js'));
assert.ok(imports.indexOf('./js/ribbon-renderer.js')<imports.indexOf('./js/finger-trails.js'),'shared ribbon renderer loads before pointer adapter');
let time=0,id=0,drawCalls=0,sandbox,portal,pageSession,material;
const timers=new Map(),rafs=new Map(),elements=new Map();
function eventTarget(extra={}){const target={handlers:{},...extra};target.addEventListener=(type,fn)=>{(target.handlers[type]??=[]).push(fn);};return target;}
function emit(target,type,event={}){assert.ok(target.handlers[type]?.length,'registered event: '+type);for(const fn of target.handlers[type])fn({type,preventDefault(){},...event});}
function makeContext(){
  const state={globalAlpha:1,globalCompositeOperation:'source-over',lineWidth:1,fillStyle:'#000',strokeStyle:'#000'},stack=[];
  const finite=(args,key)=>{for(const n of args)if(typeof n==='number')assert.ok(Number.isFinite(n),'finite Canvas '+key);};
  const gradient=(...args)=>{finite(args,'gradient');return {addColorStop(at,color){assert.ok(at>=0&&at<=1);assert.equal(typeof color,'string');}};};
  const methods={save(){stack.push({...state});},restore(){assert.ok(stack.length,'balanced Canvas restore');Object.assign(state,stack.pop());},createRadialGradient:gradient,createLinearGradient:gradient};
  return new Proxy(state,{get(target,key){if(key in methods)return methods[key];if(key in target)return target[key];return (...args)=>{finite(args,String(key));if(['drawImage','fill','fillRect'].includes(key))drawCalls++;};},
    set(target,key,value){if(typeof value==='number')assert.ok(Number.isFinite(value),'finite Canvas property '+String(key));if(key==='globalAlpha')assert.ok(value>=0&&value<=1,'bounded Canvas opacity: '+value);if(key==='lineWidth')assert.ok(value>0);target[key]=value;return true;}});
}
function makeElement(){
  const classes=new Set(),attrs=new Map(),context2d=makeContext(),captured=new Set();
  return eventTarget({style:{setProperty(name,value){this[name]=value;}},dataset:{},checked:true,value:'',textContent:'',className:'',children:[],
    append(...items){items.forEach(item=>this.appendChild(item));},
    appendChild(item){this.children.push(item);item.parent=this;},
    insertBefore(item,before){this.children.splice(this.children.indexOf(before),0,item);item.parent=this;},
    remove(){this.parent.children.splice(this.parent.children.indexOf(this),1);},
    querySelector(selector){this.parts??=new Map();if(!this.parts.has(selector))this.parts.set(selector,makeElement());return this.parts.get(selector);},
    classList:{add(...a){a.forEach(x=>classes.add(x));},remove(...a){a.forEach(x=>classes.delete(x));},contains(x){return classes.has(x);},toggle(x,on){if(on??!classes.has(x))classes.add(x);else classes.delete(x);}},
    focus(){},setAttribute(name,value){attrs.set(name,String(value));},getAttribute(name){return attrs.get(name)??null;},getContext(){return context2d;},
    getBoundingClientRect(){return {left:0,top:0,width:sandbox?.visualViewport.width??390,height:sandbox?.visualViewport.height??844};},
    setPointerCapture(pointerId){captured.add(pointerId);},releasePointerCapture(pointerId){captured.delete(pointerId);},hasPointerCapture(pointerId){return captured.has(pointerId);}
  });
}
function element(name){assert.ok(htmlIds.has(name),'actual DOM element exists: '+name);if(!elements.has(name))elements.set(name,makeElement());return elements.get(name);}
class ObservedPortal extends PortalScene {constructor(...args){super(...args);portal=this;}}
class ObservedSession extends R.Session {constructor(){super();pageSession=this;}}
// Real material lifecycle with an isolated drawing stub; the WebGL suite renders all six.
class ObservedMaterial extends ElementMaterialRenderer {
  constructor(){super(()=>makeElement());material=this;}
  init(){return true;}
  compile(){return {};}
  draw(_context,_background,_width,_height,frame=null){this.drawCount=(this.drawCount||0)+1;this.lastFrame=frame;return true;}
}
sandbox=eventTarget({ActiveTimeline,AdaptiveQuality,AudioManager,optionalVibrate,EffectSettings,ManaConfig:C,ManaResults:{...R,Session:ObservedSession},PortalScene:ObservedPortal,ProbabilitySettings,ElementMaterialRenderer:ObservedMaterial,RevealFlow,RevealGather,RevealAtmosphere,
  console,Math,innerWidth:390,innerHeight:844,devicePixelRatio:3,performance:{now:()=>time},navigator:{},visualViewport:eventTarget({width:390,height:844}),
  document:eventTarget({hidden:false,createElement:()=>makeElement(),getElementById:element,documentElement:makeElement(),body:makeElement(),
    querySelectorAll(selector){assert.equal(selector,'[data-flow-preview]');return [...html.matchAll(/\bdata-flow-preview[ >]/g)].map(()=>makeElement());}}),
  setTimeout(fn,delay){assert.ok(!(this instanceof ActiveTimeline),'browser timer receiver');timers.set(++id,{fn,at:time+delay});return id;},
  clearTimeout(n){assert.ok(!(this instanceof ActiveTimeline),'browser cancel receiver');timers.delete(n);},
  requestAnimationFrame(fn){rafs.set(++id,fn);return id;},cancelAnimationFrame(n){rafs.delete(n);}});
sandbox.window=sandbox;global.document=sandbox.document;
vm.createContext(sandbox);vm.runInContext(script,sandbox);
function click(name){emit(element(name),'click');}
function change(name,checked){element(name).checked=checked;emit(element(name),'change');}
function input(name,value){element(name).value=String(value);emit(element(name),'input');}
function state(){return sandbox.document.body.dataset.state;}
function tick(ms){const end=time+ms;while(time<end){time+=16;for(const [key,t]of [...timers])if(t.at<=time){timers.delete(key);t.fn();}const frames=[...rafs];rafs.clear();for(const [,fn]of frames)fn(time);assert.equal(rafs.size,1,'one visual frame loop throughout');}}
function touch(type,pointerId=1,x=130,y=440,extra={}){emit(type==='pointerdown'?element('animLayer'):sandbox,type,{pointerId,clientX:x,clientY:y,...extra});}
function noRandom(fn){const original=Math.random;Math.random=()=>{throw Error('portal animation and gestures must not draw result randomness');};try{fn();}finally{Math.random=original;}}

assert.equal(state(),'SETTINGS');assert.equal(rafs.size,1);
assert.equal(element('particleCanvas').width,780);
assert.equal(element('particleCanvas').height,1688,'mobile output preserves the reference 2x detail');
click('tab_effects');input('effect_dotCount',180);input('effect_starSize',150);
input('effect_dotDepth',175);input('effect_mistDrift',0);input('effect_starDuration',2.2);
input('effect_backgroundCenter','#102030');input('effect_backgroundOuter','#607080');
input('muggleChance',17);change('s_fire',false);
noRandom(()=>click('effectPreview'));
assert.equal(state(),'EFFECT_PREVIEW');assert.equal(portal.dots.length,180);
assert.equal(portal.settings.dotDepth,175);assert.equal(portal.motion.mistDrift,0);
assert.equal(portal.sparkleConfig.lifeMin,1.6);assert.equal(portal.settings.backgroundCenter,'#102030');
assert.equal(portal.sparkleConfig.sizeMax,60);assert.equal(pageSession.currentResult,null,'preview never draws a certification result');
touch('pointerdown');
touch('pointermove',1,250,500,{getCoalescedEvents:()=>[{clientX:180,clientY:460},{clientX:220,clientY:480}]});
assert.equal(portal.trails.active.points.length,4,'drawing consumes smooth coalesced pointer samples');
noRandom(()=>tick(2500));assert.equal(portal.speed,portal.activeSpeed);
touch('pointerup',1,270,520);
assert.deepEqual(portal.trails.strokes[0].rawTip,{x:270,y:520},'final pointerup endpoint is retained independently of the preview smoothing');
const renderedTip=portal.trails.strokes[0].points.at(-1);
assert.ok(Math.hypot(renderedTip.x-270,renderedTip.y-520)<8,'filtered final endpoint stays close to the release position');
assert.equal(portal.trails.active,null);touch('pointerdown',1,50,100);assert.equal(portal.trails.strokes.length,2);
click('effectPreviewBack');assert.equal(state(),'SETTINGS');assert.equal(portal.pointer.id,null);
assert.equal(portal.trails.strokes.length,0,'return to settings clears drawing history');
assert.equal(element('panel_effects').hidden,false);assert.equal(element('effectPreviewBack').hidden,true);
const originalPortal=portal;
noRandom(()=>click('materialPreviewOpen'));
assert.equal(state(),'ELEMENT_PREVIEW');assert.equal(element('materialControls').hidden,false);
assert.equal(pageSession.currentResult,null,'sample previews never draw a result');
assert.equal(portal.settings.backgroundCenter,EffectSettings.defaults.backgroundCenter,'samples share the approved quiet background');
for(const key of ['fire','water','wind','earth','light','dark']){
  noRandom(()=>click('material_'+key));assert.equal(material.element,key);
  assert.equal(element('material_'+key).getAttribute('aria-pressed'),'true');assert.equal(material.time,0);
  noRandom(()=>tick(100));assert.ok(material.time>0);
}
touch('pointerdown',20);touch('pointermove',20,200,200);touch('pointerup',20);
assert.equal(portal.pointer.id,null);assert.equal(originalPortal.trails.strokes.length,0,'material samples cannot draw finger trails');
click('materialPause');const materialTime=material.time,backdropTime=portal.time;
tick(1000);assert.equal(material.time,materialTime);assert.equal(portal.time,backdropTime,'pause freezes the full sample');
click('materialReplay');assert.equal(material.time,0);assert.equal(material.paused,false);
tick(200);sandbox.document.hidden=true;emit(sandbox.document,'visibilitychange');
const hiddenMaterialTime=material.time;tick(1000);assert.equal(material.time,hiddenMaterialTime,'backgrounding pauses materials');
sandbox.document.hidden=false;emit(sandbox.document,'visibilitychange');tick(16);assert.ok(material.time-hiddenMaterialTime<.1);
click('effectPreviewBack');assert.equal(state(),'SETTINGS');assert.equal(element('materialControls').hidden,true);
const closedMaterialTime=material.time;tick(200);assert.equal(material.time,closedMaterialTime);
assert.equal(element('muggleChance').value,'17');assert.equal(element('s_fire').checked,false,'sample selection never edits outcome settings');
portal=originalPortal;
// The interactive reveal is a separate preview; input may never select an outcome.
noRandom(()=>click('flowPreviewOpen'));
assert.equal(state(),'FLOW_PREVIEW');assert.equal(element('materialReplay').textContent,'重新畫一次');
const flowPortal=portal;
touch('pointerdown',31,100,250);touch('pointerup',31,100,250);
noRandom(()=>tick(1600));assert.equal(element('materialStatus').textContent,'畫完後放開','a tap has no reveal');
touch('pointerdown',32,100,250);touch('pointermove',32,230,400);
noRandom(()=>tick(7000));assert.equal(element('materialStatus').textContent,'畫完後放開','holding never starts the reveal');
touch('pointerup',32,230,400);
const releaseFlowTime=flowPortal.trails.time,releaseAgeTime=flowPortal.trails.ageTime;
const releaseOpacity=flowPortal.trails.opacity(flowPortal.trails.strokes.at(-1));
tick(700);
assert.ok(flowPortal.trails.time>releaseFlowTime+.6,'release waiting advances the live ribbon animation clock');
assert.ok(Math.abs(flowPortal.trails.ageTime-releaseAgeTime)<1e-9,'waiting keeps ink life without freezing its animation');
assert.equal(flowPortal.trails.opacity(flowPortal.trails.strokes.at(-1)),releaseOpacity);
assert.equal(element('materialStatus').textContent,'可接著畫');
touch('pointerdown',33,230,400);touch('pointermove',33,190,460);tick(800);
assert.equal(element('materialStatus').textContent,'畫完後放開','continuing cancels the pending reveal');
touch('pointerup',33,190,460);tick(1250);
assert.equal(element('materialStatus').textContent,'魔力收束');
const snapshot=JSON.stringify(flowPortal.trails.strokes.map(s=>s.points));
touch('pointerdown',34,80,280);touch('pointermove',34,340,550);touch('pointerup',34);
assert.equal(JSON.stringify(flowPortal.trails.strokes.map(s=>s.points)),snapshot,'input is locked once gathering starts');
click('materialPause');tick(2000);assert.equal(element('materialStatus').textContent,'已暫停');
click('materialPause');tick(900);
assert.equal(element('materialStatus').textContent,'魔力收束','the expanded cloud is still in its slow outward phase');
tick(600);
assert.equal(element('materialStatus').textContent,'魔力收束','the return remains active after the previous 1.5-second gather duration');
tick(600);assert.equal(element('materialStatus').textContent,'屬性形成');
sandbox.document.hidden=true;emit(sandbox.document,'visibilitychange');const pausedFlowTime=flowPortal.time;
tick(9000);assert.equal(flowPortal.time,pausedFlowTime);
sandbox.document.hidden=false;emit(sandbox.document,'visibilitychange');tick(16);
assert.equal(element('materialStatus').textContent,'屬性形成','hidden interval cannot skip phases');
noRandom(()=>tick(3900)); // Fire now grows for 1.2 s (other materials retain 0.8 s).
assert.equal(element('materialStatus').textContent,'播放完成');assert.equal(element('revealTitle').textContent,'火屬性');
assert.equal(pageSession.currentResult,null,'a complete flow preview does not draw a certification result');
assert.equal(element('resultCard').classList.contains('show'),false,'preview never displays a fabricated result');
click('materialReplay');assert.equal(flowPortal.trails.strokes.length,0);assert.equal(element('revealTitle').hidden,true);
for(const key of ['water','wind','earth','light','dark','fire']){
  click('material_'+key);assert.equal(material.element,key);assert.equal(flowPortal.trails.strokes.length,0);
}
touch('pointerdown',35,110,310);touch('pointermove',35,210,410);touch('pointerup',35,210,410);tick(400);
emit(sandbox,'blur');tick(2000);assert.equal(element('materialStatus').textContent,'畫完後放開','blur cancels the waiting countdown');
click('effectPreviewBack');assert.equal(state(),'SETTINGS');assert.equal(element('revealTitle').hidden,true);
assert.equal(element('materialControls').hidden,true);
const stoppedFlowTime=flowPortal.time;tick(2000);assert.equal(flowPortal.time,stoppedFlowTime);
assert.equal(element('muggleChance').value,'17');assert.equal(element('s_fire').checked,false);
portal=originalPortal;
click('effect_reset_background');assert.equal(element('effect_backgroundCenter').value,'#080915');
assert.equal(Number(element('effect_dotDepth').value),175,'background reset leaves particle tuning unchanged');
click('effect_reset_stars');assert.equal(Number(element('effect_starSize').value),100);
assert.equal(Number(element('effect_starDuration').value),1.1);
assert.equal(Number(element('effect_dotCount').value),180);
click('effectResetAll');assert.equal(Number(element('effect_dotCount').value),55);
assert.equal(element('effect_starEnabled').checked,false,'approved reference keeps the large ambient stars disabled by default');
assert.equal(element('muggleChance').value,'17');assert.equal(element('s_fire').checked,false,'effect reset cannot alter result switches');
change('s_master',true);click('restoreProbabilities');click('tab_switches');
assert.equal(element('panel_switches').hidden,false);
assert.equal(element('panel_probabilities').hidden,true);
click('tab_probabilities');
input('muggleChance',17);
assert.equal(element('panel_switches').hidden,true);
assert.equal(element('panel_probabilities').hidden,false);
click('tab_effects');
assert.equal(element('panel_probabilities').hidden,true);
assert.equal(element('panel_effects').hidden,false);
assert.equal(element('tab_effects').getAttribute('aria-selected'),'true');
click('tab_probabilities');
assert.equal(element('muggleChance').value,'17','tab switching preserves edited probabilities');
click('restoreProbabilities');click('tab_switches');
assert.equal(element('panel_effects').hidden,true);
change('s_master',false);assert.equal(element('btnStart').disabled,true);
click('btnStart');assert.equal(state(),'SETTINGS','invalid settings cannot begin a round');
change('s_muggle',true);input('muggleChance',100);assert.equal(element('btnStart').disabled,false);
const materialDrawsBeforeMuggle=material.drawCount||0;
click('btnStart');assert.equal(state(),'STANDBY');
const roundResult=pageSession.currentResult;
assert.equal(roundResult.type,'muggle');assert.ok(Object.isFrozen(roundResult));
assert.equal(element('formalReplay').hidden,true,'formal replay is hidden before the reveal');
const startPhase=portal.phase;
noRandom(()=>tick(6000));assert.equal(state(),'STANDBY','idle waits indefinitely for touch');
assert.ok(portal.phase>startPhase,'idle portal rotates');assert.ok(drawCalls>0,'portal draws during page frames');
const idleSpeed=portal.speed;assert.ok(idleSpeed>0);
touch('pointermove',1,300,500);tick(500);assert.equal(portal.pointer.id,null,'hover does not take control');
assert.ok(Math.abs(portal.speed-idleSpeed)<1e-6,'hover does not accelerate');
touch('pointerdown',1,130,440,{pointerType:'mouse',button:2});assert.equal(state(),'STANDBY','right click does not start interaction');
touch('pointerdown',50,130,440);touch('pointerup',50,130,440);noRandom(()=>tick(2000));
assert.equal(state(),'INTERACTION','a stationary tap cannot start the formal reveal');
touch('pointerdown');assert.equal(state(),'INTERACTION');
touch('pointerdown',2);touch('pointerup',2);touch('pointermove',2,350,800);
assert.equal(portal.pointer.id,1,'secondary pointer cannot release the active touch');
C.interactionPreview=false; // The retired preview flag cannot interrupt held input.
noRandom(()=>{tick(1000);touch('pointermove',1,120,500);tick(59000);});
assert.equal(state(),'INTERACTION','one minute held never starts certification');
assert.ok(portal.speed>idleSpeed*2,'holding visibly accelerates rotation');
const heldSpeed=portal.speed;
const formalReleaseTime=portal.trails.time,formalReleaseAge=portal.trails.ageTime;
touch('pointerup');assert.equal(portal.pointer.id,null);noRandom(()=>tick(160));
assert.ok(portal.speed<heldSpeed,'release begins slowing rotation');
assert.ok(portal.trails.time>formalReleaseTime,'formal release waiting keeps the ribbon animation moving');
assert.ok(Math.abs(portal.trails.ageTime-formalReleaseAge)<1e-9,'formal release retains ink age without freezing animation');
noRandom(()=>tick(1100));assert.equal(state(),'GATHER','a meaningful released drawing enters the shared gather sequence');
assert.equal(pageSession.currentResult,roundResult,'touch cannot change the preselected outcome');
noRandom(()=>tick(6000));assert.equal(state(),'ELEMENT_REVEAL','formal flow stops at the attribute reveal');
assert.equal(element('revealTitle').textContent,'未顯現屬性','muggle does not receive a fabricated element');
assert.equal(element('revealTitle').hidden,false);assert.equal(element('formalReplay').hidden,false);
assert.equal(element('materialControls').hidden,true,'formal flow hides the prototype element and pause controls');
assert.equal(material.drawCount||0,materialDrawsBeforeMuggle,'muggle never draws a material shader');
noRandom(()=>tick(60000));assert.equal(state(),'ELEMENT_REVEAL','formal endpoint remains visible indefinitely');
assert.equal(pageSession.currentResult,roundResult,'the revealed round remains immutable');
assert.equal(element('resultCard').classList.contains('show'),false,'results remain hidden');
assert.equal(timers.size,0,'no automatic result transition is scheduled');

click('formalReplay');assert.equal(state(),'STANDBY');
const lifecycleResult=pageSession.currentResult;
assert.notEqual(lifecycleResult,roundResult,'formal replay begins a fresh round');
assert.equal(element('revealTitle').hidden,true);assert.equal(element('formalReplay').hidden,true);
// Cancel, capture loss, blur, rotation and backgrounding release control.
touch('pointerdown',3);touch('pointercancel',3);assert.equal(portal.pointer.id,null);assert.equal(portal.trails.active,null);
touch('pointerdown',7);emit(element('animLayer'),'lostpointercapture',{pointerId:7});assert.equal(portal.pointer.id,null);
touch('pointerdown',8);emit(sandbox,'blur');assert.equal(portal.pointer.id,null);
touch('pointerdown',9);sandbox.innerWidth=sandbox.visualViewport.width=844;sandbox.innerHeight=sandbox.visualViewport.height=390;
emit(sandbox,'resize');assert.equal(portal.pointer.id,null);assert.equal(portal.width,844);assert.equal(portal.height,390);tick(100);
sandbox.innerWidth=sandbox.visualViewport.width=390;sandbox.innerHeight=sandbox.visualViewport.height=844;emit(sandbox.visualViewport,'resize');
assert.equal(portal.width,390);assert.equal(portal.height,844);
touch('pointerdown',10);tick(100);sandbox.document.hidden=true;emit(sandbox.document,'visibilitychange');assert.equal(portal.pointer.id,null,'hidden document releases touch');
const pausedTime=portal.time,pausedPhase=portal.phase;
touch('pointerdown',10);assert.equal(portal.pointer.id,null,'hidden page rejects new control');
tick(10000);assert.equal(portal.time,pausedTime);assert.equal(portal.phase,pausedPhase,'hidden animation does not advance');
sandbox.document.hidden=false;emit(sandbox.document,'visibilitychange');tick(16);
assert.ok(portal.time-pausedTime<0.1,'resume cannot jump by the background interval');tick(500);assert.ok(portal.time>pausedTime);
touch('pointerdown',11);emit(sandbox,'pagehide');assert.equal(portal.pointer.id,null);
const pagehideTime=portal.time;tick(10000);assert.equal(portal.time,pagehideTime,'pagehide freezes even before document.hidden changes');
touch('pointerdown',12);assert.equal(portal.pointer.id,null,'pagehide rejects new control');
emit(sandbox,'pageshow');tick(100);assert.ok(portal.time>pagehideTime,'pageshow resumes safely');
assert.equal(pageSession.currentResult,lifecycleResult);
click('btnRetryCert');assert.equal(state(),'STANDBY');assert.notEqual(pageSession.currentResult,lifecycleResult,'retry selects a new round');
assert.equal(portal.pointer.id,null);assert.equal(portal.time,0,'retry resets portal time');assert.equal(element('resultCard').classList.contains('show'),false);
touch('pointerdown',13);tick(100);click('btnGoHome');assert.equal(state(),'SETTINGS');assert.equal(pageSession.currentResult,null);assert.equal(portal.pointer.id,null,'returning to settings releases active control');
const stoppedTime=portal.time;tick(8000);assert.equal(portal.time,stoppedTime,'settings pause the portal');
assert.equal(element('muggleChance').value,'100');assert.equal(timers.size,0);

// Settings still select the stored outcome and preserve light/dark rank rules.
for(const [attr,rank,ticket]of [['火','E',0.999],['水','B',0.4],['風','C',0.6],['土','D',0.8],['光','A',0],['暗','S',0.7],['火','SS',0]]){
  change('s_master',false);change('s_'+({火:'fire',水:'water',風:'wind',土:'earth',光:'light',暗:'dark'}[attr]),true);
  const original=Math.random;Math.random=rng([0,ticket,0.5]);try{click('btnStart');}finally{Math.random=original;}
  assert.equal(pageSession.currentResult.element,attr);assert.equal(pageSession.currentResult.rank,rank);
  const immutableResult=pageSession.currentResult;
  noRandom(()=>{touch('pointerdown',60,100,250);touch('pointermove',60,250,420);tick(100);touch('pointerup',60,250,420);tick(6500);});
  assert.equal(state(),'ELEMENT_REVEAL');
  assert.equal(material.element,({火:'fire',水:'water',風:'wind',土:'earth',光:'light',暗:'dark'}[attr]),'formal shader matches the selected attribute');
  assert.equal(element('revealTitle').textContent,attr+'屬性');assert.equal(element('revealTitle').hidden,false);
  assert.equal(element('materialControls').hidden,true);assert.equal(element('formalReplay').hidden,false);
  const liveMaterialTime=material.lastFrame.time;
  noRandom(()=>tick(10000));assert.equal(state(),'ELEMENT_REVEAL','formal reveal cannot advance to mana, rank, or results');
  assert.ok(material.lastFrame.time>liveMaterialTime+9,'formal material keeps animating at its endpoint');
  assert.equal(pageSession.currentResult,immutableResult,'formal reveal never redraws its result');
  assert.equal(element('resultCard').classList.contains('show'),false);
  click('effectPreviewBack');assert.equal(state(),'SETTINGS');assert.equal(element('panel_switches').hidden,false);
  assert.equal(pageSession.currentResult,null);assert.equal(element('revealTitle').hidden,true);
}
change('s_master',true);for(const key of ['fire','water','wind','earth','light','dark','muggle'])assert.equal(element('s_'+key).checked,true);
change('s_fire',false);assert.equal(element('s_master').checked,false);
input('chance_E',100);assert.equal(element('percent_E').textContent,'100%');assert.equal(Number(element('chance_SS').value),0);
change('s_master',false);change('s_fire',true);click('btnStart');assert.equal(pageSession.currentResult.rank,'E','slider reaches actual round draw');
click('btnGoHome');assert.equal(Number(element('chance_E').value),100,'rank settings survive returning home');
change('s_muggle',false);assert.equal(element('muggleChance').disabled,true);assert.equal(element('v_muggle').textContent,'關');
const toggledBefore=element('s_fire').checked;click('restoreProbabilities');assert.equal(Number(element('muggleChance').value),8);
for(const [k,v]of Object.entries(C.normalRanks))assert.equal(Number(element('chance_'+k).value),Math.round(v*100));
assert.equal(element('s_muggle').checked,false,'restore does not change switches');assert.equal(element('s_fire').checked,toggledBefore);

// Turning ink off does not remove the formal gesture or trap the round in drawing.
change('s_master',false);change('s_water',true);change('effect_trailEnabled',false);
click('btnStart');const noInkResult=pageSession.currentResult;
assert.equal(portal.settings.trailEnabled,false,'formal mode honors the saved ink switch');
noRandom(()=>{touch('pointerdown',70,90,240);touch('pointermove',70,200,360);tick(100);touch('pointerup',70,200,360);tick(5800);});
assert.equal(state(),'ELEMENT_REVEAL','a valid gesture still reaches the material with ink disabled');
assert.equal(portal.trails.strokes.length,0);assert.equal(material.element,'water');
assert.equal(pageSession.currentResult,noInkResult);click('effectPreviewBack');change('effect_trailEnabled',true);

const sw=fs.readFileSync('service-worker.js','utf8');
for(const asset of [...sw.matchAll(/"(\.\/[^"\n]+)"/g)].map(x=>x[1]))assert.ok(fs.existsSync(asset),'cached file exists: '+asset);
for(const asset of imports)assert.ok(sw.includes(asset),'page script available offline: '+asset);
JSON.parse(fs.readFileSync('manifest.webmanifest','utf8'));
delete global.document;
console.log('Page regression checks passed: immutable formal outcomes, six live attribute endpoints, muggle handling, settings, portal hold/release, pointer ownership, lifecycle and offline assets.');
