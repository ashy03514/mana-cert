/* Three concentric pressure fronts, sampled from the shared reveal clock.
 * No timers, random state, pointer ownership, or changes to the reveal outcome. */
(function(root){
  'use strict';
  const TAU=Math.PI*2;
  const clamp=v=>Math.max(0,Math.min(1,v));
  const smooth=v=>{v=clamp(v);return v*v*(3-2*v);};
  const IN_START=.48,IN_DURATION=.36,OUT_DURATION=.42;
  class RevealShockwaves {
    static sample({state,elapsed=0,width,height}={}){
      if(!Number.isFinite(elapsed)||!Number.isFinite(width)||!Number.isFinite(height)||
        elapsed<0||width<=0||height<=0)return null;
      let id,direction,progress,radius,alpha;
      if(state==='WAITING'&&elapsed>=IN_START&&elapsed<1.2){
        id=elapsed<IN_START+IN_DURATION?1:2;direction='in';
        progress=clamp((elapsed-IN_START-(id-1)*IN_DURATION)/IN_DURATION);
        const pull=.18*progress+.82*progress*progress;
        radius=Math.min(width,height)*.82*(1-pull);
        alpha=smooth(progress/.12)*(1-smooth((progress-.91)/.09));
      }else if(state==='GATHER'&&elapsed<OUT_DURATION){
        id=3;direction='out';progress=clamp(elapsed/OUT_DURATION);
        radius=Math.hypot(width,height)*.60*(1-(1-progress)**2.4);
        alpha=smooth(progress/.075)*(1-smooth((progress-.32)/.68));
      }else return null;
      return {id,direction,progress,x:width/2,y:height/2,radius,alpha};
    }
    static draw(ctx,frame={}){
      const wave=this.sample(frame);
      if(!ctx||!wave||wave.alpha<.001||wave.radius<.2)return false;
      const {x,y,radius:r,progress:p}=wave;
      const scale=Math.max(.65,Math.min(1.8,Math.min(frame.width,frame.height)/390));
      const inward=wave.direction==='in';
      // The soft density trails the moving front: outside on the way in,
      // inside on the way out. The physical radius stays circular in CSS px.
      const thickness=Math.min(r*.65,(inward?12:17)*scale);
      const inner=Math.max(0,r-thickness*(inward?.28:2.8));
      const outer=r+thickness*(inward?2.8:.28);
      const edge=(r-inner)/(outer-inner);
      const color=(a,core=false)=>core?'rgba(209,248,255,'+a+')':'rgba(131,218,255,'+a+')';
      ctx.save();
      try{
        ctx.globalCompositeOperation='source-over';ctx.globalAlpha=wave.alpha;
        const veil=ctx.createRadialGradient(x,y,inner,x,y,outer);
        veil.addColorStop(0,color(0));
        veil.addColorStop(edge*.50,color(inward?.13:.08));
        veil.addColorStop(edge,color(.36,true));
        veil.addColorStop(edge+(1-edge)*.20,color(inward?.17:.12));
        veil.addColorStop(1,color(0));
        ctx.fillStyle=veil;ctx.fillRect(x-outer,y-outer,outer*2,outer*2);
        ctx.lineWidth=(inward?1.35:1.65)*scale;
        ctx.strokeStyle=color(.58,true);ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.stroke();
        // Low-energy travelling glints give the front a little internal life
        // without turning the circular outline into a wobbly polygon.
        ctx.lineCap='round';ctx.lineWidth=.75*scale;
        for(let i=0;i<6;i++){
          const a=i*TAU/6+p*(inward?.42:-.32)+wave.id*.51;
          ctx.strokeStyle=color(.12+.12*Math.sin(i*1.7+p*5)**2,true);
          ctx.beginPath();ctx.arc(x,y,r,a,a+.12+.10*Math.sin(i*2.1)**2);ctx.stroke();
        }
        return true;
      }finally{ctx.restore();}
    }
  }
  root.RevealShockwaves=RevealShockwaves;
})(globalThis);
