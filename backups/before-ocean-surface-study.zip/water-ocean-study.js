/* SS ocean art study. Isolated from certification state and production materials. */
(function(root){
  'use strict';
  const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
  const smooth=v=>{v=clamp(v);return v*v*(3-2*v);};
  const hash=n=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);};
  const common=`
    precision highp float;
    uniform float uTime,uSurge,uAspect,uPixelRatio;
    const float PI=3.14159265359;
    float sat(float x){return clamp(x,0.,1.);}
    float hash3(vec3 p){return fract(sin(dot(p,vec3(127.1,311.7,74.7)))*43758.5453);}
    float noise3(vec3 p){
      vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);
      return mix(mix(mix(hash3(i),hash3(i+vec3(1,0,0)),f.x),
        mix(hash3(i+vec3(0,1,0)),hash3(i+vec3(1,1,0)),f.x),f.y),
        mix(mix(hash3(i+vec3(0,0,1)),hash3(i+vec3(1,0,1)),f.x),
        mix(hash3(i+vec3(0,1,1)),hash3(i+vec3(1,1,1)),f.x),f.y),f.z);
    }
    vec3 turn(vec3 n,float a){float c=cos(a),s=sin(a);return vec3(c*n.x+s*n.z,n.y,-s*n.x+c*n.z);}
    vec4 project(vec3 p){
      float z=3.4-p.z;
      return vec4(p.x*2.61/uAspect,p.y*2.61,((20.1/19.9)*z-.201005),z);
    }
    // Unequal currents cross on a curved surface. The slower drift does not
    // lock the surface texture to the rotation of the planet.
    vec4 waves(vec3 n,float t){
      vec3 q=turn(n,t*.028);
      float a=dot(q,normalize(vec3(.90,.39,.18)));
      float b=dot(q,normalize(vec3(-.30,.88,.36)));
      float c=dot(q,normalize(vec3(-.70,.54,.46)));
      float d=dot(q,normalize(vec3(.36,.78,-.51)));
      float belt1=exp(-pow((b+.18*sin(a*5.+t*.23))/.36,2.));
      float belt2=exp(-pow((d-.18*sin(c*4.-t*.18))/.31,2.));
      float warp=noise3(q*5.3+vec3(t*.06,-t*.045,0.));
      float phase1=a*19.-t*1.65+sin(b*9.+t*.21)*1.8+warp*12.;
      float phase2=c*23.+t*1.32+sin(d*8.-t*.17)*1.5-warp*10.;
      float p1=.5+.5*sin(phase1),p2=.5+.5*sin(phase2);
      float h1=pow(p1,3.)*.025*belt1;
      float h2=pow(p2,4.)*.022*belt2;
      float ripple=sin(a*61.-t*2.1+b*4.)*sin(c*47.+t*1.7)*.0038;
      float height=(h1+h2-.010+ripple)*(.65+.35*uSurge);
      float crest1=pow(p1,3.5)*belt1;
      float crest2=pow(p2,4.0)*belt2;
      float wake=pow(.5+.5*sin(phase1-.8),4.)*belt1*.55
        +pow(.5+.5*sin(phase2+.8),5.)*belt2*.48;
      return vec4(height,crest1+crest2,wake,p1*p2*belt1*belt2);
    }
    vec3 surface(vec3 n){return n*(1.+waves(n,uTime).x);}
    vec3 flowCoords(vec3 n,float t){
      vec3 q=turn(n,t*.028);
      return q+vec3(sin(q.y*4.+t*.23),cos(q.z*4.-t*.18),sin(q.x*5.-t*.13))*.045
        +vec3(-t*.021,t*.014,t*.019);
    }
  `;
  const sphereVertex=common+`
    attribute vec3 aPosition;
    varying vec3 vPosition,vNormal,vSurface;
    varying vec2 vLip;
    void main(){
      vec3 n=normalize(aPosition),p=surface(n);
      vec3 tangent=normalize(cross(abs(n.y)>.95?vec3(1,0,0):vec3(0,1,0),n));
      vec3 bitangent=normalize(cross(n,tangent));
      float e=.003;
      vec3 px=surface(normalize(n+tangent*e)),py=surface(normalize(n+bitangent*e));
      vNormal=normalize(cross(px-p,py-p));vPosition=p;vSurface=n;vLip=vec2(0.);
      gl_Position=project(p);
    }
  `;
  const curlCommon=`
    uniform float uLane;
    vec3 curlPoint(vec2 uv){
      float cycle=fract((uTime+.55)/3.7),phase=sat((cycle-uLane*.045)/.92);
      float grow=smoothstep(.06,.30,phase)*(1.-smoothstep(.64,.94,phase));
      float side=uLane<.5?-1.:1.;
      float along=mix(.48,.045,smoothstep(.08,.58,phase))*side;
      float tilt=.48+sin(floor((uTime+.55)/3.7)*1.71)*.16;
      vec3 N=normalize(vec3(along,.04+sin(uTime*.19)*.08,.96));
      vec3 B=normalize(vec3(cos(tilt)*-side,sin(tilt)*-side,0.));
      B=normalize(B-N*dot(N,B));
      vec3 T=normalize(cross(N,B));
      float s=uv.x,v=uv.y;
      float end=pow(max(0.,1.-s*s),1.4);
      float arch=.009*sin(s*8.+uTime*.9)+.005*sin(s*17.-uTime*.8);
      float lengthwise=s*(.32+.04*sin(uTime*.31+uLane));
      float x,h;
      if(v<.56){float f=v/.56;x=mix(-.19,.045,f);h=.10*sin(f*PI*.5);}
      else{float roll=mix(.22,1.32,smoothstep(.14,.53,phase));float a=(v-.56)/.44*PI*roll;x=.045+.055*sin(a);h=.045+.055*cos(a);}
      float lift=grow*end*(.70+.30*uSurge);
      vec3 n=normalize(N+T*lengthwise+B*(x+arch));
      float base=waves(n,uTime).x;
      // The rear foot and the rounded ends merge beneath the moving sea.
      return n*(1.+base+h*lift-.010*(1.-end)*grow-.015*(1.-grow));
    }
  `;
  const curlVertex=common+curlCommon+`
    attribute vec3 aPosition;
    varying vec3 vPosition,vNormal,vSurface;
    varying vec2 vLip;
    void main(){
      vec2 uv=aPosition.xy;vec3 p=curlPoint(uv);
      vec3 px=curlPoint(uv+vec2(.003,0)),py=curlPoint(uv+vec2(0,.003));
      vPosition=p;vNormal=normalize(cross(px-p,py-p));vSurface=normalize(p);
      vLip=vec2(uv.y,pow(max(0.,1.-uv.x*uv.x),1.4));
      gl_Position=project(p);
    }
  `;
  const waterFragment=common+`
    varying vec3 vPosition,vNormal,vSurface;
    varying vec2 vLip;
    uniform float uCurl;
    void main(){
      vec3 unit=normalize(vSurface),n=normalize(vNormal),eye=normalize(vec3(0,0,3.4)-vPosition);
      if(uCurl<.5){
        vec3 tx=normalize(cross(abs(unit.y)>.95?vec3(1,0,0):vec3(0,1,0),unit));
        vec3 ty=cross(unit,tx);float e=.0015;
        float h=waves(unit,uTime).x;
        float hx=waves(normalize(unit+tx*e),uTime).x;
        float hy=waves(normalize(unit+ty*e),uTime).x;
        n=normalize(unit-tx*(hx-h)/e-ty*(hy-h)/e);
      }
      if(dot(n,eye)<0.)n=-n;
      vec3 q=flowCoords(vSurface,uTime);
      q=mat3(.80,-.36,.48,.60,.48,-.64,0.,.80,.60)*q;
      float grain=noise3(q*87.);
      float fine=noise3(q*167.+vec3(0.,uTime*.16,0.));
      float mid=noise3(q*34.+vec3(uTime*.06,0.,0.));
      vec3 ripples=vec3(noise3(q*59.+11.),noise3(q*59.+29.),noise3(q*59.+53.))-.5;
      vec3 k1=vec3(82.,38.,-46.),k2=vec3(-37.,96.,63.),k3=vec3(121.,-55.,77.);
      vec3 wavelet=normalize(k1)*cos(dot(q,k1)-uTime*1.4+mid*3.)*.12
        +normalize(k2)*cos(dot(q,k2)+uTime*1.8+grain*2.)*.10
        +normalize(k3)*cos(dot(q,k3)-uTime*2.5+mid*4.)*.060;
      ripples=ripples*.20+wavelet;
      n=normalize(n+ripples-vSurface*dot(ripples,vSurface));
      vec4 w=waves(vSurface,uTime);
      float face=sat(dot(n,eye));
      float fresnel=.025+.975*pow(1.-face,5.);
      vec3 light=normalize(vec3(-.48,.76,.65));
      float diffuse=.62+.38*sat(dot(n,light));
      float height=smoothstep(-.010,.032,w.x);
      vec3 deep=vec3(.012,.115,.188),shallow=vec3(.032,.38,.47);
      vec3 color=mix(deep,shallow,height*.66)*diffuse;
      // Dark valleys under the crest preserve the thickness of a curling wall.
      float curlWall=uCurl*smoothstep(.05,.3,vLip.x)*(1.-smoothstep(.56,.88,vLip.x))*vLip.y;
      color+=vec3(.018,.13,.17)*curlWall;
      color*=1.-uCurl*smoothstep(.68,.95,vLip.x)*.30;
      vec3 reflection=reflect(-eye,n);
      float sky=smoothstep(-.45,.85,reflection.y);
      vec3 environment=mix(vec3(.012,.065,.100),vec3(.20,.48,.57),sky);
      color=mix(color,environment,fresnel*.72);
      vec3 halfLight=normalize(light+eye);
      float spec=pow(sat(dot(n,halfLight)),105.);
      float broad=pow(sat(dot(n,halfLight)),16.);
      float fill=pow(sat(dot(n,normalize(eye+vec3(.7,-.2,.6)))),20.);
      color+=vec3(.33,.65,.72)*spec*.65+vec3(.040,.10,.12)*broad+vec3(.018,.085,.10)*fill;
      // Foam is created on breaking crests; a trailing, fragmented wake is
      // carried by the local current instead of rotating with a single map.
      float broken=smoothstep(.30,.69,mid*.52+grain*.48);
      float filament=1.-smoothstep(.012,.055,abs(grain-.51));
      float crest=smoothstep(.14,.87,w.y)*(.22+.78*broken);
      float wake=smoothstep(.34,.78,w.z)*filament*broken*.50;
      float lip=uCurl*exp(-pow((vLip.x-.62)/.075,2.))*vLip.y;
      float foam=sat(crest*.92+wake+lip*(.43+.48*broken));
      foam*=.38+.62*smoothstep(.20,.62,fine);
      float lace=filament*smoothstep(.35,.65,mid)*smoothstep(.18,.55,w.y+w.z);
      // Small whitecaps and thin wakes break up the otherwise calm valleys.
      // They follow a finer current with a different speed from the main swell.
      float secondary=noise3(q*19.+vec3(-uTime*.09,uTime*.04,0.));
      float cap=smoothstep(.58,.79,mid)*smoothstep(.40,.67,secondary);
      float threads=filament*cap*(.4+.6*fine);
      foam=sat(foam+lace*.35+threads*.52+cap*.22);
      vec3 foamColor=mix(vec3(.12,.44,.53),vec3(.78,.95,.97),.35+.65*diffuse);
      color=mix(color,foamColor,foam);
      float rim=pow(1.-sat(dot(normalize(vSurface),eye)),4.);
      color+=vec3(.025,.20,.24)*rim*(.35+.65*sat(dot(vSurface,light)));
      color=pow(max(vec3(0.),color),vec3(.87));
      gl_FragColor=vec4(color,1.);
    }
  `;
  const sprayVertex=common+`
    attribute vec3 aPosition;
    varying float vAlpha,vCold;
    void main(){
      float id=aPosition.x,seed=aPosition.y;
      float cycle=floor((uTime+.55)/3.7),phase=fract((uTime+.55)/3.7);
      float birth=.32+seed*.22,age=(phase-birth)*3.7;
      float life=.40+aPosition.z*.28;
      float active=step(0.,age)*(1.-step(life,age));
      age=max(0.,age);
      float angle=id*2.39996+cycle*.63;
      vec3 origin=normalize(vec3(sin(angle)*.25,.06+cos(angle)*.26,.97));
      vec3 side=vec3(cos(angle),sin(angle),0.);
      vec3 velocity=origin*(.24+seed*.22)+side*(.10+aPosition.z*.24);
      vec3 p=origin*(1.08+.04*seed)+velocity*age+vec3(0.,-.36*age*age,0.);
      vAlpha=active*sin(sat(age/life)*PI)*(.25+seed*.50)*uSurge;
      vCold=seed;
      gl_Position=project(p);
      gl_PointSize=(.65+aPosition.z*1.35)*uPixelRatio;
    }
  `;
  const sprayFragment=`precision mediump float;varying float vAlpha,vCold;
    void main(){float d=length(gl_PointCoord-.5);float a=(1.-smoothstep(.16,.5,d))*vAlpha;
    gl_FragColor=vec4(mix(vec3(.40,.77,.87),vec3(.88,.98,1.),vCold),a);}`;

  function meshSphere(cols=192,rows=128){
    const vertices=[],indices=[];
    for(let y=0;y<=rows;y++){
      const phi=y/rows*Math.PI;
      for(let x=0;x<=cols;x++){
        const a=x/cols*Math.PI*2;
        vertices.push(Math.sin(phi)*Math.cos(a),Math.cos(phi),Math.sin(phi)*Math.sin(a));
      }
    }
    for(let y=0;y<rows;y++)for(let x=0;x<cols;x++){
      const a=y*(cols+1)+x,b=a+cols+1;
      indices.push(a,b,a+1,a+1,b,b+1);
    }
    return {vertices:new Float32Array(vertices),indices:new Uint16Array(indices)};
  }
  function meshCurl(cols=96,rows=40){
    const vertices=[],indices=[];
    for(let y=0;y<=rows;y++)for(let x=0;x<=cols;x++)vertices.push(x/cols*2-1,y/rows,0);
    for(let y=0;y<rows;y++)for(let x=0;x<cols;x++){
      const a=y*(cols+1)+x,b=a+cols+1;indices.push(a,a+1,b,a+1,b+1,b);
    }
    return {vertices:new Float32Array(vertices),indices:new Uint16Array(indices)};
  }
  class WaterOceanStudy{
    constructor(canvas){
      this.canvas=canvas;this.error='';this.diagnostic='';this.gl=null;this.resources=[];this.drawCount=0;this.disposed=false;
      this.onLost=e=>{e.preventDefault();this.lost=true;this.error='水面特效暫時中斷，等待恢復。';};
      this.onRestored=()=>{this.lost=false;this.error='';this.init();};
      canvas.addEventListener('webglcontextlost',this.onLost);canvas.addEventListener('webglcontextrestored',this.onRestored);
      this.init();
    }
    static frameAt(time){
      const t=Math.max(0,Number.isFinite(time)?time:0),phase=((t+.55)%3.7)/3.7;
      return Object.freeze({time:t,phase,collision:smooth((phase-.24)/.18)*(1-smooth((phase-.60)/.25))});
    }
    init(){
      try{
        const gl=this.canvas.getContext('webgl',{alpha:true,premultipliedAlpha:false,antialias:true,depth:true,preserveDrawingBuffer:true});
        if(!gl)throw new Error('WebGL unavailable');this.gl=gl;this.resources=[];
        this.waterProgram=this.program(sphereVertex,waterFragment);this.curlProgram=this.program(curlVertex,waterFragment);
        this.sprayProgram=this.program(sprayVertex,sprayFragment);
        this.sphere=this.upload(meshSphere());this.curl=this.upload(meshCurl());
        const points=[];for(let i=0;i<220;i++)points.push(i,hash(i+4),hash(i+91));
        this.spray=this.upload({vertices:new Float32Array(points)});
        gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.disable(gl.CULL_FACE);
      }catch(e){this.diagnostic=String(e);this.error='這個裝置暫時無法顯示水之星球樣板。';}
    }
    program(vertex,fragment){
      const gl=this.gl,program=gl.createProgram();this.resources.push(['program',program]);
      for(const [type,source]of [[gl.VERTEX_SHADER,vertex],[gl.FRAGMENT_SHADER,fragment]]){
        const shader=gl.createShader(type);gl.shaderSource(shader,source);gl.compileShader(shader);
        if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS)){const err=gl.getShaderInfoLog(shader);gl.deleteShader(shader);throw new Error(err);}
        gl.attachShader(program,shader);gl.deleteShader(shader);
      }
      gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(program));
      const uniforms={};for(const n of ['uTime','uSurge','uAspect','uPixelRatio','uLane','uCurl'])uniforms[n]=gl.getUniformLocation(program,n);
      return {program,uniforms,position:gl.getAttribLocation(program,'aPosition')};
    }
    upload(data){
      const gl=this.gl,vertices=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,vertices);gl.bufferData(gl.ARRAY_BUFFER,data.vertices,gl.STATIC_DRAW);this.resources.push(['buffer',vertices]);
      let indices=null;if(data.indices){indices=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,indices);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,data.indices,gl.STATIC_DRAW);this.resources.push(['buffer',indices]);}
      return {vertices,indices,count:data.indices?.length??data.vertices.length/3};
    }
    resize(width,height,dpr=1){
      this.width=Math.max(1,width);this.height=Math.max(1,height);
      // The prototype retains fine foam at phone size with a bounded buffer.
      this.pixelRatio=Math.min(1.75,Math.max(1,dpr),880/Math.max(width,height));
      const w=Math.max(1,Math.round(width*this.pixelRatio)),h=Math.max(1,Math.round(height*this.pixelRatio));
      if(this.canvas.width!==w||this.canvas.height!==h){this.canvas.width=w;this.canvas.height=h;}
    }
    bind(program,mesh,time,surge,lane=0,curl=0){
      const gl=this.gl;gl.useProgram(program.program);gl.bindBuffer(gl.ARRAY_BUFFER,mesh.vertices);
      gl.enableVertexAttribArray(program.position);gl.vertexAttribPointer(program.position,3,gl.FLOAT,false,0,0);
      const u=program.uniforms;gl.uniform1f(u.uTime,time);gl.uniform1f(u.uSurge,surge);
      gl.uniform1f(u.uAspect,this.canvas.width/this.canvas.height);gl.uniform1f(u.uPixelRatio,this.pixelRatio||1);
      gl.uniform1f(u.uLane,lane);gl.uniform1f(u.uCurl,curl);
      if(mesh.indices){gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,mesh.indices);gl.drawElements(gl.TRIANGLES,mesh.count,gl.UNSIGNED_SHORT,0);}
      else gl.drawArrays(gl.POINTS,0,mesh.count);
    }
    draw(time,{surge=1}={}){
      if(this.disposed||this.lost||this.error||!this.gl)return false;
      time=WaterOceanStudy.frameAt(time).time;surge=clamp(surge);
      const gl=this.gl;gl.viewport(0,0,this.canvas.width,this.canvas.height);gl.clearColor(0,0,0,0);
      gl.depthMask(true);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.disable(gl.BLEND);
      this.bind(this.waterProgram,this.sphere,time,surge);
      this.bind(this.curlProgram,this.curl,time,surge,0,1);this.bind(this.curlProgram,this.curl,time,surge,1,1);
      gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);
      this.bind(this.sprayProgram,this.spray,time,surge);gl.depthMask(true);gl.disable(gl.BLEND);
      this.time=time;this.drawCount++;return true;
    }
    dispose(){
      if(this.disposed)return;this.disposed=true;const gl=this.gl;
      if(gl&&!this.lost)for(const[type,item]of this.resources){if(type==='buffer')gl.deleteBuffer(item);else gl.deleteProgram(item);}
      this.resources=[];this.canvas.removeEventListener('webglcontextlost',this.onLost);this.canvas.removeEventListener('webglcontextrestored',this.onRestored);
    }
  }
  root.WaterOceanStudy=WaterOceanStudy;
})(globalThis);
