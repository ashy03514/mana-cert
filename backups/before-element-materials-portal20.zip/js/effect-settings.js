/* Versioned device-local visual settings. Never used by result probabilities. */
(function(root){
  'use strict';
  const key='mana.portal.effects.v1';
  const range=(group,label,value,min,max,step=1,unit='%')=>({group,label,value,min,max,step,unit,type:'range'});
  const color=(group,label,value)=>({group,label,value,type:'color'});
  const toggle=(group,label,value=true)=>({group,label,value,type:'checkbox'});
  const fields={
    idleSeconds:range('motion','待機每圈秒數',Math.PI*2/.075,10,180,.1,'秒'),
    activeSeconds:range('motion','按住每圈秒數',1,.3,5,.1,'秒'),
    acceleration:range('motion','加速時間',2,.2,8,.1,'秒'),
    deceleration:range('motion','恢復時間',2,.2,8,.1,'秒'),
    mistEnabled:toggle('mist','顯示霧'),
    mistCount:range('mist','霧團總數',30,12,144,1,'團'),
    mistSize:range('mist','大小',100,50,200,5),
    mistOpacity:range('mist','濃淡',100,10,150,5),
    mistDrift:range('mist','飄動程度',100,0,200,5),
    mistColor1:color('mist','色彩一','#6457a2'),mistColor2:color('mist','色彩二','#6457a2'),mistColor3:color('mist','色彩三','#6457a2'),
    dotEnabled:toggle('dots','顯示圓點'),
    dotCount:range('dots','圓點總數',55,12,306,1,'顆'),
    dotSize:range('dots','大小',100,50,250,5),
    dotOpacity:range('dots','亮度',100,10,150,5),
    dotSpeed:range('dots','速度倍率',100,25,200,5),
    dotDepth:range('dots','深度感',100,0,200,5),
    dotColor:color('dots','顏色','#d7dbf6'),
    starEnabled:toggle('stars','顯示星芒',false),
    starSize:range('stars','大小',100,50,200,5),
    starOpacity:range('stars','亮度',100,10,115,5),
    starIdle:range('stars','待機出現頻率',100,25,200,5),
    starHeld:range('stars','按住出現頻率',100,25,200,5),
    starDuration:range('stars','平均持續時間',1.1,.3,3.5,.1,'秒'),
    starBlue:toggle('stars','啟用色彩一'),starColor1:color('stars','色彩一（預設螢光藍）','#65eaff'),
    starPurple:toggle('stars','啟用色彩二'),starColor2:color('stars','色彩二（預設螢光紫）','#ce83ff'),
    starWhite:toggle('stars','啟用色彩三'),starColor3:color('stars','色彩三（預設白色）','#ffffff'),
    backgroundCenter:color('background','中央顏色','#080915'),
    backgroundOuter:color('background','外圍顏色','#24223f'),
    trailEnabled:toggle('trails','顯示手指軌跡'),
    trailWidth:range('trails','光帶粗細',2.5,1,6,.5,'px'),
    trailOpacity:range('trails','線條亮度',86,10,100,1),
    trailGlowSize:range('trails','光暈大小',10,4,24,1,'px'),
    trailGlowOpacity:range('trails','光暈亮度',30,0,60,5),
    trailFingerSize:range('trails','指尖光點大小',24,8,32,1,'px'),
    trailHold:range('trails','放開後停留時間',2,0,8,.1,'秒'),
    trailFade:range('trails','淡出時間',1.5,.2,4,.1,'秒'),
    trailFlowEnabled:toggle('trails','沿線能量流動'),
    trailFlowDensity:range('trails','流動亮段數量',100,0,200,5),
    trailFlowSpeed:range('trails','能量流動速度',100,25,200,5),
    trailDustEnabled:toggle('trails','星塵、細閃與消散光點'),
    trailDustDensity:range('trails','星塵與光點數量',100,0,200,5),
    trailRandom:toggle('trails','每筆隨機選色',false),
    trailBlue:toggle('trails','啟用色彩一'),trailColor1:color('trails','色彩一（預設螢光藍）','#7deaff'),
    trailPurple:toggle('trails','啟用色彩二'),trailColor2:color('trails','色彩二（預設螢光紫）','#ce83ff'),
    trailWhite:toggle('trails','啟用色彩三'),trailColor3:color('trails','色彩三（預設白色）','#ffffff')
  };
  const defaults=Object.freeze(Object.fromEntries(Object.entries(fields).map(([k,f])=>[k,f.value])));
  function normalize(input){
    const source=input&&typeof input==='object'?input:{};
    const result={};
    for(const [k,f] of Object.entries(fields)){
      const v=source[k];
      result[k]=f.type==='range'?(typeof v==='number'&&Number.isFinite(v)?Math.min(f.max,Math.max(f.min,v)):f.value)
        :f.type==='color'?(typeof v==='string'&&/^#[0-9a-f]{6}$/i.test(v)?v.toLowerCase():f.value)
        :typeof v==='boolean'?v:f.value;
    }
    result.mistCount=Math.round(result.mistCount);result.dotCount=Math.round(result.dotCount);
    if(!result.starBlue&&!result.starPurple&&!result.starWhite)result.starWhite=true;
    if(!result.trailBlue&&!result.trailPurple&&!result.trailWhite)result.trailWhite=true;
    return result;
  }
  const appearanceRevision=2,backupKey=key+'.before-reference';
  function load(storage){
    try{
      const raw=storage.getItem(key),data=JSON.parse(raw);
      if(data?.version!==1)return normalize();
      if(data.appearanceRevision===appearanceRevision)return normalize(data.values);
      // Apply the approved whole-scene appearance once. Keep the user's speed
      // controls and preserve a recoverable copy of all previous visual values.
      const old=normalize(data.values),next=normalize();
      for(const [k,f] of Object.entries(fields))if(f.group==='motion')next[k]=old[k];
      try{
        if(!storage.getItem(backupKey))storage.setItem(backupKey,raw);
        save(storage,next);
      }catch(_){/* Restricted storage must not prevent rendering the new look. */}
      return next;
    }catch(_){return normalize();}
  }
  function save(storage,values){try{storage.setItem(key,JSON.stringify({version:1,appearanceRevision,values:normalize(values)}));return true;}catch(_){return false;}}
  const defaultsKey=key+'.user-defaults';
  function loadDefaults(storage){
    try{const data=JSON.parse(storage.getItem(defaultsKey));return normalize(data?.version===1?data.values:null);}
    catch(_){return normalize();}
  }
  function saveDefaults(storage,values){
    try{storage.setItem(defaultsKey,JSON.stringify({version:1,values:normalize(values)}));return true;}
    catch(_){return false;}
  }
  function resetGroup(values,group,preset=defaults){const next={...values},target=normalize(preset);for(const [k,f] of Object.entries(fields))if(f.group===group)next[k]=target[k];return normalize(next);}
  function mount(doc,storage,onChange){
    let values=load(storage);
    const status=doc.getElementById('effectSaveStatus');
    const setDefault=doc.getElementById('effectSetDefault');
    function render(){for(const [k,f] of Object.entries(fields)){
      const input=doc.getElementById('effect_'+k);
      if(f.type==='checkbox')input.checked=values[k];else input.value=values[k];
      if(f.type==='range')doc.getElementById('effect_value_'+k).textContent=Number(values[k].toFixed(1))+f.unit;
    }}
    function commit(){render();setDefault.textContent='設為預設';status.textContent=save(storage,values)?'已儲存在此裝置':'本次調整已套用；此裝置目前無法儲存。';onChange(values);}
    for(const [k,f] of Object.entries(fields)){
      const input=doc.getElementById('effect_'+k);
      input.addEventListener(f.type==='checkbox'?'change':'input',()=>{
        values=normalize({...values,[k]:f.type==='checkbox'?input.checked:f.type==='range'?Number(input.value):input.value});commit();
      });
    }
    for(const group of new Set(Object.values(fields).map(f=>f.group)))doc.getElementById('effect_reset_'+group).addEventListener('click',()=>{values=resetGroup(values,group,loadDefaults(storage));commit();});
    doc.getElementById('effectResetAll').addEventListener('click',()=>{values=loadDefaults(storage);commit();});
    setDefault.addEventListener('click',()=>{
      const saved=saveDefaults(storage,values);
      setDefault.textContent=saved?'已設為預設':'儲存失敗';
      status.textContent=saved?'目前特效已設為此裝置的預設值':'無法儲存預設值，原本的預設值未變更。';
    });
    render();onChange(values);
  }
  root.EffectSettings={fields,defaults,normalize,load,save,loadDefaults,saveDefaults,resetGroup,mount};
})(globalThis);
