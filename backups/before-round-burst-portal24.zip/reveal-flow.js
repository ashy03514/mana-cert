/* Preview-only pacing. No timers, DOM, randomness, or certification outcome. */
(function(root) {
  'use strict';
  const ELEMENTS=Object.freeze(['fire','water','wind','earth','light','dark']);
  const DURATIONS=Object.freeze({WAITING:1.2,GATHER:1.5,FORM:.8,REVEAL:1.8,SETTLE:.8});
  const NEXT=Object.freeze({WAITING:'GATHER',GATHER:'FORM',FORM:'REVEAL',REVEAL:'SETTLE',SETTLE:'DONE'});
  const clamp=v=>Math.max(0,Math.min(1,v));
  const smooth=v=>{const x=clamp(v);return x*x*(3-2*x);};

  class RevealFlow {
    constructor(){this.reset();}
    reset(element='fire'){
      this.element=ELEMENTS.includes(element)?element:'fire';
      this.state='DRAWING';this.elapsed=0;this.paused=false;
      this.pointerId=null;this.distance=0;this._point=null;
      return this;
    }
    get ready(){return this.distance>=24;}
    get gatherDuration(){return DURATIONS.GATHER;}
    get progress(){
      if(this.state==='DONE')return 1;
      return DURATIONS[this.state]?clamp(this.elapsed/DURATIONS[this.state]):0;
    }
    get materialFrame(){
      let time,opacity;
      if(this.state==='FORM'){
        time=this.elapsed;opacity=smooth(this.progress);
      }else if(this.state==='REVEAL'){
        time=DURATIONS.FORM+this.elapsed;opacity=1;
      }else if(this.state==='SETTLE'){
        time=DURATIONS.FORM+DURATIONS.REVEAL+this.elapsed;
        opacity=1-.55*smooth(this.progress);
      }else if(this.state==='DONE'){
        time=DURATIONS.FORM+DURATIONS.REVEAL+DURATIONS.SETTLE;opacity=.45;
      }else return null;
      return {time,phase:clamp(time/6.4),opacity};
    }
    down(id,x,y){
      if(this.paused||this.pointerId!==null||id===null||id===undefined||
        !Number.isFinite(x)||!Number.isFinite(y)||
        (this.state!=='DRAWING'&&this.state!=='WAITING'))return false;
      this.pointerId=id;this._point={x,y};this.state='DRAWING';this.elapsed=0;
      return true;
    }
    move(id,x,y){
      if(this.paused||this.pointerId===null||id!==this.pointerId||
        !Number.isFinite(x)||!Number.isFinite(y))return false;
      const distance=Math.hypot(x-this._point.x,y-this._point.y);
      // Keep the last meaningful point so tiny back-and-forth input jitter
      // cannot become a completed drawing after a stationary long press.
      if(distance<2)return false;
      this.distance=Math.min(1e6,this.distance+distance);this._point={x,y};
      return true;
    }
    up(id,{cancelled=false}={}){
      if(this.paused||this.pointerId===null||id!==this.pointerId)return false;
      if(cancelled){this.cancelPointer();return true;}
      this.pointerId=null;this._point=null;this.elapsed=0;
      this.state=this.ready?'WAITING':'DRAWING';
      return true;
    }
    cancelPointer(){
      // Lifecycle cancellation must still release capture while animation is paused.
      this.pointerId=null;this._point=null;
      if(this.state==='WAITING'||this.state==='DRAWING'){
        this.state='DRAWING';this.elapsed=0;
      }
    }
    step(dt){
      if(this.paused||!Number.isFinite(dt)||dt<=0||!DURATIONS[this.state])return;
      let remaining=Math.min(dt,.05);
      while(remaining>0&&DURATIONS[this.state]){
        const duration=DURATIONS[this.state],untilEnd=Math.max(0,duration-this.elapsed);
        if(remaining+1e-9<untilEnd){this.elapsed+=remaining;break;}
        remaining=Math.max(0,remaining-untilEnd);
        this.state=NEXT[this.state];this.elapsed=0;
      }
    }
  }
  root.RevealFlow=RevealFlow;
})(globalThis);
