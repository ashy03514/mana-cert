(function(root) {
  'use strict';
  class MagicRenderer {
    constructor(context, field, createCanvas = () => document.createElement('canvas')) {
      this.ctx=context;this.field=field;
      this.colors=['#ffe4a4','#d1b9f3','#a9e3dc'];
      // Small reusable glow textures: no shadowBlur, gradient creation, or pools allocated per frame.
      this.sprites=this.colors.map(color => {
        const canvas=createCanvas();canvas.width=canvas.height=64;
        const c=canvas.getContext('2d'),g=c.createRadialGradient(32,32,0,32,32,32);
        g.addColorStop(0,'#fff9ea');g.addColorStop(0.12,color);g.addColorStop(0.4,color+'60');g.addColorStop(1,color+'00');
        c.fillStyle=g;c.fillRect(0,0,64,64);return canvas;
      });
      this.fog=createCanvas();this.fog.width=this.fog.height=128;
      const fogCtx=this.fog.getContext('2d'),fog=fogCtx.createRadialGradient(61,59,0,64,64,64);
      fog.addColorStop(0,'#9d93b350');fog.addColorStop(0.36,'#82799430');fog.addColorStop(0.72,'#69658310');fog.addColorStop(1,'#69658300');
      fogCtx.fillStyle=fog;fogCtx.fillRect(0,0,128,128);
      this.mist=createCanvas();this.mist.width=this.mist.height=128;
      const m=this.mist.getContext('2d'),haze=m.createRadialGradient(64,64,0,64,64,64);
      haze.addColorStop(0,'#725cdb90');haze.addColorStop(.3,'#535bd66a');
      haze.addColorStop(.65,'#3447a82c');haze.addColorStop(1,'#25378000');
      m.fillStyle=haze;m.fillRect(0,0,128,128);
    }
    draw(gather=0,resonance=0,quality=null,standby=null) {
      const c=this.ctx,f=this.field;
      c.clearRect(0,0,f.width,f.height);c.save();c.globalCompositeOperation='lighter';
      const fade=f.gathering?Math.max(0,1-Math.pow(gather,5)):1;
      const quiet=standby?standby.weight:0;
      if(quiet>0)this.nebula(standby,quality);
      this.drawMist(fade,quiet,quality);
      c.globalCompositeOperation='lighter';
      // Uneven translucent clouds behind the dust; no rigid central disc.
      for(let i=0;i<(quality&&!quality.glow?1:3);i++) {
        const collapse=f.gathering?1-gather*gather:1;
        const r=Math.min(f.width*0.62,245)*collapse,x=f.width/2+Math.sin(f.time*0.3+i*2)*48*collapse,y=f.height/2+Math.cos(f.time*0.4+i)*55*collapse;
        c.globalAlpha=(0.08+resonance*0.08)*fade*(1-quiet);c.drawImage(this.sprites[i],x-r,y-r,r*2,r*2);
      }
      const trails=f.trails;
      // Preserve the original additive glow and ribbon, with 25% less light per sample.
      const trailBrightness=0.75;
      for(let i=0;i<trails.length;i++) {
        if(quality&&i%quality.trailStep)continue;
        const t=trails[(f.trailHead+i)%trails.length];if(t.life<=0)continue;
        const life=Math.min(1,t.life/(f.config.trailLife/2)),width=t.width*(0.5+life*0.8);
        c.globalAlpha=life*life*(0.25+resonance*0.1)*fade*trailBrightness;
        c.drawImage(this.sprites[t.stroke%3],t.x-width,t.y-width,width*2,width*2);
        // Three varying-width translucent layers make a liquid ribbon, not a plain line.
        const previous=trails[(f.trailHead+i+trails.length-1)%trails.length];
        if(i && previous.life>0 && previous.stroke===t.stroke && Math.hypot(t.x-previous.x,t.y-previous.y)<100) {
          c.lineCap='round';c.strokeStyle=this.colors[t.stroke%3];
          for(let layer=quality&&!quality.glow?1:0;layer<3;layer++) {
            c.globalAlpha=life*life*(layer===2?0.3:0.045)*fade*trailBrightness;
            c.lineWidth=width*(layer===0?1.3:layer===1?0.48:0.07);
            c.beginPath();c.moveTo(previous.x,previous.y);
            c.quadraticCurveTo((previous.x+t.x)/2-t.vy*0.012,(previous.y+t.y)/2+t.vx*0.012,t.x,t.y);c.stroke();
          }
        }
      }
      c.globalCompositeOperation='lighter';
      for(let index=0;index<f.particles.length;index++) {
        const q=f.particles[index];
        if(quality&&q.kind===0&&index%quality.particleStep)continue;
        const twinkle=0.65+Math.sin(f.time*(1+q.depth)*(1-quiet*0.7)+q.seed)*0.25;
        c.globalAlpha=twinkle*fade*(q.kind===2?0.09:0.55+resonance*0.3);
        c.globalAlpha*=1-quiet*(q.kind===1?(index%4===0?0.15:0.45):q.kind===2?0.55:0.08);
        c.globalAlpha*=q.idleAlpha??1;
        c.globalAlpha*=q.feedAlpha??1;
        if(index%20===0)this.meteorTail(q,this.colors[q.tint],f.pointer.strength);
        if(q.kind===2) {const r=22+q.depth*20;c.drawImage(this.sprites[q.tint],q.x-r,q.y-r,r*2,r*2);continue;}
        const r=(q.kind===1?5+q.depth*5:1.4+q.depth*2.1)*(1+quiet*(q.kind===0?0.9:0.25));
        c.drawImage(this.sprites[q.tint],q.x-r,q.y-r,r*2,r*2);
        if(q.kind===0&&quiet>0){
          c.fillStyle=this.colors[q.tint];c.beginPath();
          c.arc(q.x,q.y,(0.65+q.depth*0.45)*quiet,0,Math.PI*2);c.fill();
        }
        if(q.kind===1) {
          c.fillStyle=this.colors[q.tint];c.beginPath();
          const size=(1.8+q.depth*1.8)*(1+quiet*0.15);
          c.arc(q.x,q.y,size*0.55,0,Math.PI*2);c.fill();
        }
      }
      for(let i=0;i<(f.touchParticles?.length??0);i++){
        const q=f.touchParticles[i];if(q.life<=0)continue;
        const life=Math.max(0,Math.min(1,q.life/1.25)),size=Math.sqrt(life),r=(3+(i%3))*size;
        c.globalAlpha=life*life*0.75*fade;
        if((f.particles.length+i)%20===0)this.meteorTail(q,this.colors[i%3],f.pointer.strength);
        c.drawImage(this.sprites[i%3],q.x-r,q.y-r,r*2,r*2);
        c.fillStyle=this.colors[i%3];c.beginPath();c.arc(q.x,q.y,(0.7+(i%3)*0.2)*size,0,Math.PI*2);c.fill();
      }
      c.restore();
    }
    drawMist(fade,quiet,quality){
      const c=this.ctx,f=this.field;
      c.save();c.globalCompositeOperation='source-over';
      // Independent atmospheric clouds respond to swipes, not particle attraction.
      for(const q of f.mistClouds){
        const t=f.time,s=q.seed;
        const envelope=fade*(0.32+0.06*Math.sin(t*.7+s))*(1-quiet*.25);
        for(let l=0;l<(quality&&quality.name==='LOW'?2:3);l++){
          const a=s+l*2.1+t*.19;
          const x=q.x+Math.cos(a)*13,y=q.y+Math.sin(a*1.2)*11;
          const rx=27+8*Math.sin(t*.45+s+l),ry=20+6*Math.cos(t*.36+s-l);
          c.globalAlpha=envelope*(l===0?1:.65);
          c.drawImage(this.mist,x-rx,y-ry,rx*2,ry*2);
        }
      }
      c.restore();
    }
    meteorTail(q,color,attraction){
      if(this.field.gathering||attraction<0.02)return;
      const speed=Math.hypot(q.vx,q.vy);if(speed<1)return;
      const c=this.ctx,alpha=c.globalAlpha;
      const length=Math.min(48,5+speed*0.075)*attraction*9;
      if(!q.tail||q.tailCount<2)return;
      c.strokeStyle=color;c.lineCap='round';
      // Follow sampled travel history, so the tail bends instead of rotating as a rod.
      let x=q.x,y=q.y,travel=0;
      for(let i=0;i<q.tailCount&&travel<length;i++){
        const slot=(q.tailHead-1-i+128)%128;
        let nx=q.tail[slot*2],ny=q.tail[slot*2+1];
        const distance=Math.hypot(nx-x,ny-y);if(distance<0.01)continue;
        const portion=Math.min(1,(length-travel)/distance);
        nx=x+(nx-x)*portion;ny=y+(ny-y)*portion;
        const a=travel/length;
        c.globalAlpha=alpha*(1-a)*(1-a)*0.55;
        c.lineWidth=(0.8+(q.depth??0.6))*(1-a*0.85);
        c.beginPath();c.moveTo(x,y);c.lineTo(nx,ny);c.stroke();
        travel+=distance*portion;x=nx;y=ny;
      }
      c.globalAlpha=alpha;
    }
    nebula(idle,quality){
      const c=this.ctx,f=this.field,t=idle.time,w=idle.weight;
      const radius=Math.min(32,f.width*0.085),cx=f.width/2,cy=f.height/2;
      // Normal compositing keeps the liquid translucent instead of adding a white core.
      c.save();c.globalCompositeOperation='source-over';c.beginPath();
      for(let j=0;j<=96;j++){
        const a=j/96*Math.PI*2;
        const r=radius*(0.86+0.018*Math.sin(t*0.48)+0.025*Math.sin(a*3+t*0.31)+0.014*Math.sin(a*5-t*0.23));
        const x=cx+Math.cos(a)*r,y=cy+Math.sin(a)*r*(1.035+0.012*Math.sin(t*0.37));
        if(j===0)c.moveTo(x,y);else c.lineTo(x,y);
      }
      c.closePath();c.globalAlpha=w*0.85;c.fillStyle='#291065';c.fill();
      c.globalAlpha=w*0.75;c.strokeStyle='#973eff';c.lineWidth=2;c.stroke();c.clip();
      const coreKey=`${cx},${cy},${radius}`;
      if(this.coreKey!==coreKey){
      const core=c.createRadialGradient(cx,cy,0,cx,cy,radius);
      core.addColorStop(0,'#fff2ff');core.addColorStop(.12,'#ffb5ff');core.addColorStop(.28,'#e33dff');
      core.addColorStop(.52,'#7321d7');core.addColorStop(.72,'#461389');core.addColorStop(.9,'#883bdf');core.addColorStop(1,'#391369');
      this.coreGradient=core;this.coreKey=coreKey;
      }
      c.globalAlpha=w*(0.85+Math.sin(t*.65)*.06);c.fillStyle=this.coreGradient;c.fillRect(cx-radius,cy-radius,radius*2,radius*2);
      const count=quality&&quality.name==='LOW'?3:5;
      for(let i=0;i<count;i++){
        const a=i*2.399+t*(0.045+i*0.009),spread=radius*0.52;
        const x=cx+Math.cos(a)*spread+Math.sin(t*0.19+i)*radius*0.1;
        const y=cy+Math.sin(a*1.13)*spread*0.8+Math.cos(t*0.15+i*2)*radius*0.09;
        const rx=radius*(0.65+0.08*Math.sin(t*0.36+i*1.4)),ry=radius*(0.77+0.1*Math.sin(t*0.28+i*2.1));
        c.globalAlpha=w*(0.24+Math.sin(t*0.43+i*1.7)*0.04);
        c.drawImage(this.fog,x-rx,y-ry,rx*2,ry*2);
      }
      // Offset reflections follow the surface; the center remains dim.
      for(let i=0;i<2;i++){
        c.beginPath();
        for(let j=0;j<=32;j++){
          const a=3.5+i*2.9+j/32*0.95+Math.sin(t*0.22+i)*0.08;
          const r=radius*(0.79+0.02*Math.sin(a*3+t*0.31));
          const x=cx+Math.cos(a)*r,y=cy+Math.sin(a)*r*1.04;
          if(j===0)c.moveTo(x,y);else c.lineTo(x,y);
        }
        c.globalAlpha=w*(0.09+0.025*Math.sin(t*0.39+i));
        c.strokeStyle=i?'#7045ed':'#e087ff';c.lineWidth=2.4;c.lineCap='round';c.stroke();
      }
      // Extremely faint short internal filaments; never a complete orbit/radar ring.
      const event=idle.event===2?Math.sin(Math.PI*Math.min(1,idle.age/2.6)):0;
      for(let i=0;i<3;i++){
        const envelope=Math.pow(Math.max(0,Math.sin(t*0.24+i*2)),4);
        c.globalAlpha=w*(envelope*0.022+event*0.035);c.strokeStyle='#c0b8d3';c.lineWidth=0.7;
        const a=t*0.055+i*2.1;
        c.beginPath();c.moveTo(cx+Math.cos(a)*radius*0.52,cy+Math.sin(a)*radius*0.42);
        c.bezierCurveTo(cx-radius*0.15,cy-radius*0.35,cx+radius*0.24,cy+radius*0.3,cx+Math.cos(a+1.4)*radius*0.5,cy+Math.sin(a+1.4)*radius*0.5);c.stroke();
      }
      c.restore();
      // Near-invisible ambient haze extends space above/below the central cloud.
      c.globalAlpha=w*0.09;
      c.drawImage(this.fog,cx-radius*1.5,cy-radius*2.1,radius*3,radius*4.2);
    }
  }
  root.MagicRenderer=MagicRenderer;
})(globalThis);
