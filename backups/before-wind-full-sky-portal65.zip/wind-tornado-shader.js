/* SS wind study: advected cloud volume, not stroked spiral ribbons.
 * The host supplies the active clock and composites premultiplied transparency.
 */
(function(root){
  'use strict';
  const vertex=`
    attribute vec2 aPosition;
    varying vec2 vUv;
    void main(){vUv=aPosition*.5+.5;gl_Position=vec4(aPosition,0.,1.);}
  `;
  const fragment=`
    precision highp float;
    varying vec2 vUv;
    uniform float uTime,uAspect,uFormation;
    float sat(float x){return clamp(x,0.,1.);}
    float sq(float x){return x*x;}
    float hash(vec3 p){
      // Arithmetic hash: volume noise does not need eight sin() calls per cell.
      p=fract(p*.1031);p+=dot(p,p.yzx+33.33);
      return fract((p.x+p.y)*p.z);
    }
    float noise3(vec3 p){
      vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);
      return mix(mix(mix(hash(i),hash(i+vec3(1.,0.,0.)),f.x),
                     mix(hash(i+vec3(0.,1.,0.)),hash(i+vec3(1.,1.,0.)),f.x),f.y),
                 mix(mix(hash(i+vec3(0.,0.,1.)),hash(i+vec3(1.,0.,1.)),f.x),
                     mix(hash(i+vec3(0.,1.,1.)),hash(i+vec3(1.,1.,1.)),f.x),f.y),f.z);
    }
    mat2 turn(float a){float c=cos(a),s=sin(a);return mat2(c,-s,s,c);}
    vec2 spine(float h,float t){
      // Large S bends belong to the waist, not the broad crown. Secondary
      // bends travel at a different cadence; h=0 stays anchored to the floor.
      // Keep this base spine in sync with the surface-arc projection in host.
      float bend=4.*h*(1.-h);
      return vec2(.23*bend*sin(7.1*h-.75*t)
                    +.055*bend*sin(12.2*h+.97*t)
                    +.075*h*sin(4.2*h-.37*t),
                  .10*bend*sin(6.4*h-.58*t)
                    +.035*h*sin(3.9*h+.42*t));
    }
    float stormCloud(vec3 p,float t,bool shadowSample){
      if(p.y<.56||p.y>1.43)return 0.;
      vec2 q=p.xz-spine(1.,t)*.45;
      float radius=length(q);
      if(radius>1.02)return 0.;
      // Connected 3D billows give the deck real thickness. A height field
      // alone creates paper-thin shelves when several depths overlap.
      vec2 orbit=turn(-t*.60)*q;
      float volume=0.;
      for(int l=0;l<5;l++){
        float fi=float(l),a=fi*1.256637;
        vec2 centre=vec2(cos(a),sin(a))*(.43+.035*sin(fi*3.1));
        float y=1.065+.055*sin(fi*2.3+t*.36);
        vec3 local=vec3((orbit-centre).x/.40,(p.y-y)/(.235+.025*sin(fi*4.7)),(orbit-centre).y/.40);
        volume=max(volume,1.-smoothstep(.63,1.23,length(local)));
      }
      // Fill the central storm eye's upper roof while its lower surface
      // remains recessed and feeds the funnel below.
      float roof=1.-smoothstep(.64,1.15,length(vec3(q/.48,(p.y-1.04)/.25)));
      volume=max(volume,roof);
      if(volume<=0.)return 0.;
      vec2 swept=turn(-t*1.35+radius*1.85)*q;
      vec3 field=vec3(swept.x*6.3,(p.y-1.)*7.0,swept.y*6.3)+vec3(4.7,-t*.32,9.2);
      float cells=noise3(field);
      float wisps=noise3(field*2.3+vec3(7.1,3.4,12.2));
      float cloudNoise=cells*.74+wisps*.26;
      float billow=max(0.,volume-.08+(cloudNoise-.48)*.23);
      float spiral=.84+.16*cos(atan(q.y,q.x+.000001)*2.+radius*7.+t*2.7+cells*1.3);
      float density=billow*(.54+1.65*smoothstep(.21,.77,cloudNoise))*spiral;
      return density*(1.-smoothstep(1.34,1.42,p.y))*(1.-smoothstep(.94,1.,abs(p.x)));
    }
    float density(vec3 p,float t,bool shadowSample){
      float h=(p.y+.86)/1.78;
      float height=sat(h);
      vec2 q=p.xz-spine(height,t);
      float radius=length(q);
      // Most slices miss the narrow lower funnel. Reject them before noise;
      // retain wider bounds only where crown or ground eddies can contribute.
      float envelope=.054+.54*pow(height,1.45)+.14*pow(height,5.);
      float bound=envelope*1.58+.025;
      if(p.y>.57)bound=max(bound,1.0);
      if(p.y<-.63)bound=max(bound,.82);
      if(radius>bound||p.y< -1.08||p.y>1.43)return 0.;
      float angle=atan(q.y,q.x+.000001);
      // Cloud cells are swept around, stretched tangentially and lifted.
      // Sampling a rotated Cartesian field avoids an atan texture seam.
      // Keep vertical shear bounded. A height-dependent angular speed would
      // wind the cloud field into thinner stripes forever during long play.
      float rotation=-t*1.85+height*3.3+.52*sin(height*4.8-t*.57);
      vec2 spinning=turn(rotation)*q;
      vec3 flow=vec3(spinning.x*5.4,p.y*5.1-t*1.15,spinning.y*5.4);
      float broad=noise3(flow*.62+vec3(8.1,3.7,12.6));
      float detail=noise3(flow*1.73+vec3(broad*1.5,5.4,17.2));
      // Lighting needs broad self-shadowing, not another full fine-noise pass.
      float fine=detail;
      if(!shadowSample)fine=noise3(flow*4.12+vec3(21.8,-t*.22,6.3));
      float turbulence=broad*.60+detail*.25+fine*.15;
      envelope*=1.+.085*sin(height*11.-t*.83+broad*4.)+.20*(broad-.5);
      float normalized=radius/max(.035,envelope);
      // The rim is broken into irregular cloud tufts. A weaker interior lets
      // the shadowed far side show through without making a hollow wire coil.
      float edge=1.-smoothstep(.72+(turbulence-.5)*.40,1.12+(turbulence-.5)*.48,normalized);
      float shell=.48+.52*exp(-sq((normalized-.74)/.37));
      float churn=smoothstep(.29,.70,turbulence);
      float corkscrew=.5+.5*sin(angle*3.-height*13.+t*2.4+broad*5.);
      float fold=.76+.24*corkscrew;
      // Denser connected cloud cells retain the dark interior because the
      // lighting path uses extinction; density is not added white emission.
      float body=edge*shell*(.23+1.65*churn)*fold;
      float cap=.99+.17*(broad-.5)+.055*sin(angle*3.-t*.48);
      body*=smoothstep(-.035,.065,h)*(1.-smoothstep(cap-.085,cap+.085,h));

      float crown=stormCloud(p,t,shadowSample);

      // Thin ground-level eddies curl into the base; their patchiness and
      // drifting radius avoid a complete luminous ellipse around the foot.
      float dust=0.;
      float intake=0.;
      if(p.y<-.57){
        vec2 dustFlow=turn(-t*2.25)*p.xz;
        float dustCloud=noise3(vec3(dustFlow*7.6,t*.38));
        float dustRadius=.32+.075*sin(angle*3.+t*.78)+.055*(dustCloud-.5);
        dust=exp(-sq((radius-dustRadius)/.19));
        dust*=exp(-sq((p.y+.85-radius*.035)/(.030+.032*dustCloud)));
        dust*=smoothstep(.26,.73,dustCloud)*.80;
        intake=exp(-sq(radius/.20)-sq((p.y+.81)/.085))*.43;
      }
      float form=smoothstep(0.,.16,uFormation);
      float rise=1.-smoothstep(uFormation+.01,uFormation+.19,height);
      rise=mix(rise,1.,smoothstep(.83,1.,uFormation));
      return (body+crown+dust+intake)*form*rise;
    }
    void main(){
      vec2 screen=(vUv-.5)*vec2(2.,2.*uAspect);
      // Frame the complete crown and floor eddies, including the upper cloud
      // tufts, so the camera cannot crop them into a flat horizontal edge.
      screen.y+=.20;
      if(uFormation<=0.||abs(screen.x)>1.10||screen.y< -1.20||screen.y>1.54){gl_FragColor=vec4(0.);return;}
      vec3 accumulated=vec3(0.);
      float transmission=1.;
      // Fixed bounded raymarch. The slight downward view reveals crown depth
      // and makes the near ground eddy pass in front of the contact point.
      const float stepSize=2.2/32.;
      vec3 light=normalize(vec3(-.58,.74,.49));
      for(int i=0;i<32;i++){
        float z=1.1-(float(i)+.5)*stepSize;
        vec3 p=vec3(screen.x,screen.y-z*.105,z);
        float d=density(p,uTime,false);
        if(d>.012){
          float litDensity=density(p+light*.075,uTime,true);
          // Broad extinction darkens the deep folds; the density gradient
          // picks out sunward cloud tufts without an emissive white core.
          float direct=clamp(.46+(d-litDensity)*2.35,.08,1.);
          float broadLight=sat(.55-p.x*.48+p.z*.19);
          float occlusion=exp(-litDensity*1.55);
          float illumination=sat(direct*.53+broadLight*.19+occlusion*.28);
          illumination=pow(illumination,1.27);
          // Thick clouds occlude overhead light on their lower shelf. This
          // broad value change gives the storm depth instead of a white cap.
          float cloudShade=smoothstep(.69,.91,p.y)*(1.-smoothstep(1.02,1.25,p.y));
          float upperLight=smoothstep(.87,1.17,p.y);
          illumination*=1.-cloudShade*(.32-.24*upperLight);
          vec3 tint=mix(vec3(.055,.105,.13),vec3(.79,.86,.84),illumination);
          float dustTint=1.-smoothstep(-.83,-.65,p.y);
          tint=mix(tint,tint*vec3(1.04,.99,.88),dustTint*.55);
          float alpha=1.-exp(-d*stepSize*4.3);
          accumulated+=transmission*alpha*tint;
          transmission*=1.-alpha;
        }
        if(transmission<.025)break;
      }
      // Keep the volume alpha and RGB paired; screen-space compositing must
      // not turn overlapping cloud layers into an emissive white tornado.
      float alpha=1.-transmission;
      gl_FragColor=vec4(accumulated,alpha);
    }
  `;
  root.WindTornadoShader=Object.freeze({vertex,fragment});
})(globalThis);
