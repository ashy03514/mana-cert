/* SS wind preview. The host owns time, pause, formation and the result.
 * A retained 2D frame keeps a paused WebGL drawing buffer from disappearing.
 */
(function(root){
  'use strict';
  const clamp=(v,min=0,max=1)=>Math.max(min,Math.min(max,v));
  const smooth=v=>{v=clamp(v);return v*v*(3-2*v);};
  const hash=n=>{const v=Math.sin(n*127.1+311.7)*43758.5453;return v-Math.floor(v);};
  // One visual clock for the volume, surface wind and airborne debris. The
  // host's clock and phase lengths stay unchanged, including pause and replay.
  const VISUAL_SPEED=1.5;
  class WindTornadoRenderer {
    constructor(createCanvas=()=>document.createElement('canvas')){
      this.canvas=createCanvas();this.patch=createCanvas();this.patchCtx=this.patch.getContext('2d');
      this.gl=null;this.program=null;this.buffer=null;this.uniforms={};
      this.error='';this.lost=false;this.disposed=false;this.time=0;this.visualTime=0;
      this.lastTime=-Infinity;this.lastKey='';this.drawCount=0;this.renderBox=null;
      this.onLost=event=>{event.preventDefault();this.lost=true;this.error='龍捲風暫時中斷，正在等待恢復。';};
      this.onRestored=()=>{
        if(this.disposed)return;
        this.gl=null;this.program=null;this.buffer=null;this.lost=false;this.error='';
        this.lastTime=-Infinity;this.lastKey='';this.init();
      };
      this.canvas.addEventListener('webglcontextlost',this.onLost);
      this.canvas.addEventListener('webglcontextrestored',this.onRestored);
      this.init();
    }
    init(){
      if(this.lost||this.disposed||this.error)return false;
      if(this.program)return true;
      const shaders=[];let program=null;
      try{
        const gl=this.gl||this.canvas.getContext('webgl',{alpha:true,premultipliedAlpha:true,
          antialias:false,depth:false,stencil:false,preserveDrawingBuffer:false});
        if(!gl)throw Error('WebGL unavailable');
        this.gl=gl;
        for(const [type,source] of [[gl.VERTEX_SHADER,root.WindTornadoShader.vertex],[gl.FRAGMENT_SHADER,root.WindTornadoShader.fragment]]){
          const shader=gl.createShader(type);shaders.push(shader);gl.shaderSource(shader,source);gl.compileShader(shader);
          if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(shader));
        }
        program=gl.createProgram();shaders.forEach(shader=>gl.attachShader(program,shader));gl.linkProgram(program);
        if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));
        this.program=program;this.position=gl.getAttribLocation(program,'aPosition');
        for(const name of ['uTime','uAspect','uFormation'])this.uniforms[name]=gl.getUniformLocation(program,name);
        this.buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,this.buffer);
        gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),gl.STATIC_DRAW);
        gl.disable(gl.DEPTH_TEST);gl.disable(gl.BLEND);this.error='';return true;
      }catch(error){
        if(program)this.gl.deleteProgram(program);this.program=null;
        this.error='目前無法顯示龍捲風，請返回設定後重試。';this.diagnostic=String(error);return false;
      }finally{if(this.gl)shaders.forEach(shader=>this.gl.deleteShader(shader));}
    }
    layout(width,height){
      const h=Math.max(40,Math.min(height*.55,height-278,550));
      const w=Math.min(width*.96,h/1.34);
      return {x:(width-w)/2,y:54,width:w,height:w*1.34};
    }
    spine(h,time){
      // Match the volume's bounded S bend so surface streaks and leaves never
      // orbit an old, straight axis while the visible funnel moves away.
      const bend=4*h*(1-h);
      return {
        x:.23*bend*Math.sin(7.1*h-.75*time)+.055*bend*Math.sin(12.2*h+.97*time)+.075*h*Math.sin(4.2*h-.37*time),
        z:.10*bend*Math.sin(6.4*h-.58*time)+.035*h*Math.sin(3.9*h+.42*time)
      };
    }
    surface(h,angle,time){
      const {x,z}=this.spine(h,time);
      const radius=.054+.54*Math.pow(h,1.45)+.14*Math.pow(h,5);
      return {x:x+Math.cos(angle)*radius,z:z+Math.sin(angle)*radius,y:-.86+h*1.78};
    }
    speedLines(ctx,box,time,formation,front){
      const unit=box.width/2,cx=box.x+unit,cy=box.y+box.height/2+.10*unit;
      ctx.save();ctx.lineCap='round';ctx.lineJoin='round';
      const opacity=ctx.globalAlpha;
      // Short, staggered crests wrap around the current curved surface. Their
      // far half is drawn under the volume, not as flat white marks on top.
      for(let i=0;i<22;i++){
        const period=.95+hash(i+41)*.9,clock=time/period+hash(i+22),age=clock%1;
        const seed=i*31+Math.floor(clock)*79;
        const headH=.12+.74*hash(seed+3)+.08*age;
        const pulse=smooth(age/.14)*(1-smooth((age-.64)/.36));
        const emerge=smooth((formation-headH)/.16);
        if(pulse*emerge<.01)continue;
        const headAngle=-time*5.2+hash(i+15)*Math.PI*2+.4*Math.sin(headH*5-time*.43);
        const span=.75+hash(seed+5)*1.25,segments=18;
        let previous=null;
        for(let j=0;j<=segments;j++){
          const s=j/segments,h=headH-(1-s)*.105;
          const angle=headAngle+span*(1-s),q=this.surface(h,angle,time);
          const point={x:cx+q.x*unit,y:cy-(q.y+q.z*.105)*unit,z:Math.sin(angle)};
          if(previous){
            const depth=(point.z+previous.z)/2;
            if((depth>=0)===front){
              const taper=Math.pow(Math.sin(Math.PI*(s-.5/segments)),.8);
              const alpha=pulse*emerge*taper*(front?.22+.48*Math.sqrt(Math.max(0,depth)):.16);
              const width=(.65+hash(seed+7)*.65)*(box.width/360)*(.6+.4*taper);
              ctx.beginPath();ctx.moveTo(previous.x,previous.y);ctx.lineTo(point.x,point.y);
              ctx.globalAlpha=opacity*alpha*.18;ctx.lineWidth=width*3.2;
              ctx.strokeStyle='#a4d3d0';ctx.stroke();
              ctx.globalAlpha=opacity*alpha;ctx.lineWidth=width;
              ctx.strokeStyle='#d9e8df';ctx.stroke();
            }
          }
          previous=point;
        }
      }
      ctx.restore();
    }
    debris(ctx,box,time,formation,front){
      const unit=box.width/2,cx=box.x+unit,cy=box.y+box.height/2+.10*unit;
      for(let i=0;i<34;i++){
        const leaf=i<9,seed=i*17+11,period=3.5+hash(seed)*3.2;
        const h=(time/period+hash(seed+1))%1;
        const angle=-time*3.4+h*.8+hash(seed+2)*Math.PI*2;
        const z=Math.sin(angle);if((z>=0)!==front)continue;
        const radius=.12+.55*Math.pow(h,1.4)+hash(seed+3)*.10;
        const spine=this.spine(h,time);
        const x=cx+(spine.x+Math.cos(angle)*radius)*unit;
        const y=cy-(-.83+h*1.75+(spine.z+z*radius)*.105)*unit;
        const alpha=smooth(h/.08)*(1-smooth((h-.83)/.17))*smooth((formation-h)/.2)*(.27+.26*(z+1)/2);
        if(alpha<.01)continue;
        ctx.save();ctx.globalAlpha*=alpha;ctx.translate(x,y);
        ctx.rotate(angle*.7+Math.sin(time*3+seed));
        const size=(leaf?1.2+hash(seed+4)*1.3:.45+hash(seed+4)*.7)*(box.width/360)*(.78+.22*z);
        ctx.fillStyle=leaf?(i%3===0?'#b8b592':'#8aab9e'):'#b5c7c7';
        if(leaf){
          const fold=.25+.75*Math.abs(Math.sin(time*4.2+seed));
          ctx.scale(1,fold);ctx.beginPath();ctx.moveTo(-size*1.6,0);
          ctx.quadraticCurveTo(0,-size,size*1.6,0);ctx.quadraticCurveTo(0,size*.65,-size*1.6,0);ctx.fill();
        }else{ctx.beginPath();ctx.ellipse(0,0,size*1.8,size*.5,0,0,Math.PI*2);ctx.fill();}
        ctx.restore();
      }
    }
    draw(ctx,_background,width,height,frame={}){
      if(!this.init())return false;
      frame=frame||{};
      const box=frame.box||this.layout(width,height);
      if(!(box.width>0&&box.height>0))return false;
      const time=Number.isFinite(frame.time)?Math.max(0,frame.time):0;
      const formation=clamp(frame.formation??1),opacity=clamp(frame.opacity??1);
      // Bound the raymarch surface on mobile and retain its exact aspect ratio.
      const scale=Math.min(1.25,root.devicePixelRatio||1,384/box.width,480/box.height);
      const pw=Math.max(1,Math.round(box.width*scale)),ph=Math.max(1,Math.round(box.height*scale));
      const key=[pw,ph,formation].join(':');this.time=time;this.renderBox={...box};
      this.visualTime=time*VISUAL_SPEED;
      if(key!==this.lastKey||time<this.lastTime||time-this.lastTime>=1/30-1e-6){
        if(this.canvas.width!==pw||this.canvas.height!==ph){
          this.canvas.width=this.patch.width=pw;this.canvas.height=this.patch.height=ph;
        }
        const gl=this.gl;gl.viewport(0,0,pw,ph);gl.useProgram(this.program);
        gl.bindBuffer(gl.ARRAY_BUFFER,this.buffer);gl.enableVertexAttribArray(this.position);
        gl.vertexAttribPointer(this.position,2,gl.FLOAT,false,0,0);
        gl.uniform1f(this.uniforms.uTime,this.visualTime);gl.uniform1f(this.uniforms.uAspect,box.height/box.width);
        gl.uniform1f(this.uniforms.uFormation,formation);
        gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT);gl.drawArrays(gl.TRIANGLES,0,6);
        this.patchCtx.clearRect(0,0,pw,ph);this.patchCtx.drawImage(this.canvas,0,0);
        this.lastTime=time;this.lastKey=key;this.drawCount++;
      }
      ctx.save();ctx.globalCompositeOperation='source-over';ctx.globalAlpha=opacity;
      const renderedTime=this.lastTime*VISUAL_SPEED;
      this.speedLines(ctx,box,renderedTime,formation,false);
      this.debris(ctx,box,renderedTime,formation,false);
      ctx.drawImage(this.patch,box.x,box.y,box.width,box.height);
      this.speedLines(ctx,box,renderedTime,formation,true);
      this.debris(ctx,box,renderedTime,formation,true);ctx.restore();return true;
    }
    dispose(){
      if(this.disposed)return;
      this.disposed=true;
      this.canvas.removeEventListener('webglcontextlost',this.onLost);
      this.canvas.removeEventListener('webglcontextrestored',this.onRestored);
      if(this.gl&&!this.lost){this.gl.deleteProgram(this.program);this.gl.deleteBuffer(this.buffer);}
      this.program=null;this.buffer=null;this.gl=null;this.lastTime=-Infinity;
      this.canvas.width=this.canvas.height=this.patch.width=this.patch.height=1;
    }
  }
  root.WindTornadoRenderer=WindTornadoRenderer;
})(globalThis);
